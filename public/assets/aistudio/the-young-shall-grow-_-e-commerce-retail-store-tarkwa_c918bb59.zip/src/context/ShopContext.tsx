import React, { createContext, useContext, useState, useEffect } from 'react';
import { Product, CartItem, Order, PageView, ProductCategory, CustomerDetails } from '../types/ecommerce';
import { INITIAL_PRODUCTS } from '../data/initialProducts';

interface Toast {
  id: string;
  message: string;
  type: 'success' | 'info' | 'error';
}

interface ShopContextType {
  products: Product[];
  cart: CartItem[];
  orders: Order[];
  wishlist: string[];
  currentPage: PageView;
  selectedCategory: ProductCategory | 'All';
  searchQuery: string;
  selectedProduct: Product | null;
  toasts: Toast[];
  cartDrawerOpen: boolean;
  isAdmin: boolean;
  
  // Actions
  setCurrentPage: (page: PageView) => void;
  setSelectedCategory: (category: ProductCategory | 'All') => void;
  setSearchQuery: (query: string) => void;
  openProductDetail: (product: Product) => void;
  closeProductDetail: () => void;
  
  // Cart Actions
  addToCart: (product: Product, quantity?: number, color?: string) => void;
  removeFromCart: (productId: string) => void;
  updateCartQuantity: (productId: string, quantity: number) => void;
  clearCart: () => void;
  setCartDrawerOpen: (open: boolean) => void;
  
  // Wishlist Actions
  toggleWishlist: (productId: string) => void;
  
  // Order Actions
  placeOrder: (customer: CustomerDetails) => Order;
  updateOrderStatus: (orderId: string, status: Order['status']) => void;
  
  // Admin Actions
  setIsAdmin: (isAdmin: boolean) => void;
  addProduct: (product: Omit<Product, 'id'>) => void;
  updateProduct: (product: Product) => void;
  deleteProduct: (productId: string) => void;
  resetProductsToDefault: () => void;
  
  // WhatsApp Utility
  generateWhatsAppLink: (phone: string, items: CartItem[], total: number, customer?: CustomerDetails) => string;
  generateProductWhatsAppLink: (product: Product, phone?: string) => string;
  
  // Toast Utility
  showToast: (message: string, type?: 'success' | 'info' | 'error') => void;
}

const ShopContext = createContext<ShopContextType | undefined>(undefined);

const PRIMARY_PHONE = '0241890996';
const SECONDARY_PHONE = '0243276094';

export const ShopProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Load products from localStorage or fallback
  const [products, setProducts] = useState<Product[]>(() => {
    try {
      const saved = localStorage.getItem('tysg_products_v1');
      return saved ? JSON.parse(saved) : INITIAL_PRODUCTS;
    } catch {
      return INITIAL_PRODUCTS;
    }
  });

  // Load cart
  const [cart, setCart] = useState<CartItem[]>(() => {
    try {
      const saved = localStorage.getItem('tysg_cart_v1');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  // Load orders
  const [orders, setOrders] = useState<Order[]>(() => {
    try {
      const saved = localStorage.getItem('tysg_orders_v1');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  // Load wishlist
  const [wishlist, setWishlist] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('tysg_wishlist_v1');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [currentPage, setCurrentPage] = useState<PageView>('home');
  const [selectedCategory, setSelectedCategory] = useState<ProductCategory | 'All'>('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [cartDrawerOpen, setCartDrawerOpen] = useState(false);
  const [isAdmin, setIsAdmin] = useState(false);
  const [toasts, setToasts] = useState<Toast[]>([]);

  // Sync state to localStorage
  useEffect(() => {
    localStorage.setItem('tysg_products_v1', JSON.stringify(products));
  }, [products]);

  useEffect(() => {
    localStorage.setItem('tysg_cart_v1', JSON.stringify(cart));
  }, [cart]);

  useEffect(() => {
    localStorage.setItem('tysg_orders_v1', JSON.stringify(orders));
  }, [orders]);

  useEffect(() => {
    localStorage.setItem('tysg_wishlist_v1', JSON.stringify(wishlist));
  }, [wishlist]);

  // Toast notification system
  const showToast = (message: string, type: 'success' | 'info' | 'error' = 'success') => {
    const id = Math.random().toString(36).substring(2, 9);
    setToasts((prev) => [...prev, { id, message, type }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 3500);
  };

  const openProductDetail = (product: Product) => {
    setSelectedProduct(product);
    setCurrentPage('product-detail');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const closeProductDetail = () => {
    setSelectedProduct(null);
    setCurrentPage('shop');
  };

  // Cart operations
  const addToCart = (product: Product, quantity = 1, color?: string) => {
    setCart((prev) => {
      const existing = prev.find((item) => item.product.id === product.id && item.selectedColor === color);
      if (existing) {
        return prev.map((item) =>
          item.product.id === product.id && item.selectedColor === color
            ? { ...item, quantity: item.quantity + quantity }
            : item
        );
      }
      return [...prev, { product, quantity, selectedColor: color || product.colors?.[0] }];
    });
    showToast(`Added ${quantity}x "${product.name}" to cart!`, 'success');
  };

  const removeFromCart = (productId: string) => {
    setCart((prev) => prev.filter((item) => item.product.id !== productId));
    showToast('Item removed from cart', 'info');
  };

  const updateCartQuantity = (productId: string, quantity: number) => {
    if (quantity <= 0) {
      removeFromCart(productId);
      return;
    }
    setCart((prev) =>
      prev.map((item) => (item.product.id === productId ? { ...item, quantity } : item))
    );
  };

  const clearCart = () => {
    setCart([]);
  };

  // Wishlist toggle
  const toggleWishlist = (productId: string) => {
    setWishlist((prev) => {
      const exists = prev.includes(productId);
      if (exists) {
        showToast('Removed from favorites', 'info');
        return prev.filter((id) => id !== productId);
      } else {
        showToast('Saved to favorites!', 'success');
        return [...prev, productId];
      }
    });
  };

  // Place Order
  const placeOrder = (customer: CustomerDetails): Order => {
    const subtotal = cart.reduce((sum, item) => sum + item.product.price * item.quantity, 0);
    const deliveryFee = customer.deliveryMethod === 'Tarkwa Pick-Up' ? 0 : customer.deliveryMethod === 'Tarkwa Home Delivery' ? 20 : 45;
    const total = subtotal + deliveryFee;

    const newOrder: Order = {
      id: `TYSG-${Math.floor(100000 + Math.random() * 900000)}`,
      createdAt: new Date().toISOString(),
      items: [...cart],
      customer,
      subtotal,
      deliveryFee,
      total,
      status: 'Pending'
    };

    setOrders((prev) => [newOrder, ...prev]);
    clearCart();
    showToast(`Order #${newOrder.id} successfully created!`, 'success');
    return newOrder;
  };

  const updateOrderStatus = (orderId: string, status: Order['status']) => {
    setOrders((prev) =>
      prev.map((ord) => (ord.id === orderId ? { ...ord, status } : ord))
    );
    showToast(`Order status updated to ${status}`, 'info');
  };

  // Admin CRUD
  const addProduct = (productData: Omit<Product, 'id'>) => {
    const newProduct: Product = {
      ...productData,
      id: `prod-${Date.now().toString(36)}`
    };
    setProducts((prev) => [newProduct, ...prev]);
    showToast(`Product "${newProduct.name}" added successfully!`, 'success');
  };

  const updateProduct = (updated: Product) => {
    setProducts((prev) => prev.map((p) => (p.id === updated.id ? updated : p)));
    if (selectedProduct?.id === updated.id) {
      setSelectedProduct(updated);
    }
    showToast(`Updated "${updated.name}"!`, 'success');
  };

  const deleteProduct = (productId: string) => {
    setProducts((prev) => prev.filter((p) => p.id !== productId));
    showToast('Product deleted from inventory', 'info');
  };

  const resetProductsToDefault = () => {
    setProducts(INITIAL_PRODUCTS);
    localStorage.removeItem('tysg_products_v1');
    showToast('Catalog reset to initial shop defaults', 'info');
  };

  // WhatsApp Utilities
  const generateWhatsAppLink = (phone: string, items: CartItem[], total: number, customer?: CustomerDetails) => {
    const cleanPhone = phone.replace(/[^0-9]/g, '');
    const targetPhone = cleanPhone.startsWith('0') ? `233${cleanPhone.slice(1)}` : cleanPhone;

    let text = `🛒 *NEW ORDER - THE YOUNG SHALL GROW (Tarkwa)*\n`;
    text += `_______________________________\n\n`;

    items.forEach((item, index) => {
      text += `${index + 1}. *${item.product.name}*\n`;
      if (item.selectedColor) text += `   • Color/Pattern: ${item.selectedColor}\n`;
      text += `   • Quantity: ${item.quantity}\n`;
      text += `   • Price: GH₵ ${(item.product.price * item.quantity).toLocaleString()}\n\n`;
    });

    text += `_______________________________\n`;
    text += `💰 *Subtotal:* GH₵ ${total.toLocaleString()}\n`;

    if (customer) {
      const deliveryFee = customer.deliveryMethod === 'Tarkwa Pick-Up' ? 0 : customer.deliveryMethod === 'Tarkwa Home Delivery' ? 20 : 45;
      text += `🚚 *Delivery Method:* ${customer.deliveryMethod} (GH₵ ${deliveryFee})\n`;
      text += `💵 *Total Amount:* GH₵ ${(total + deliveryFee).toLocaleString()}\n\n`;
      text += `👤 *Customer Details:*\n`;
      text += `• Name: ${customer.fullName}\n`;
      text += `• Phone: ${customer.phone}\n`;
      text += `• Location: ${customer.city}, ${customer.region}\n`;
      text += `• Address: ${customer.deliveryAddress}\n`;
      text += `• Payment Choice: ${customer.paymentMethod}\n`;
      if (customer.orderNotes) text += `• Notes: ${customer.orderNotes}\n`;
    }

    text += `\nHello! I am placing this order directly from your website. Please confirm availability and delivery timing. Thank you!`;

    return `https://wa.me/${targetPhone}?text=${encodeURIComponent(text)}`;
  };

  const generateProductWhatsAppLink = (product: Product, phone: string = PRIMARY_PHONE) => {
    const cleanPhone = phone.replace(/[^0-9]/g, '');
    const targetPhone = cleanPhone.startsWith('0') ? `233${cleanPhone.slice(1)}` : cleanPhone;

    const text = `Hello *THE YOUNG SHALL GROW (Tarkwa)*,\n\nI am interested in buying your product:\n📌 *${product.name}*\n💰 *Price:* GH₵ ${product.price.toLocaleString()} per ${product.unit || 'unit'}\n🏷️ *Category:* ${product.category}\n\nPlease let me know if this is available for immediate pickup or nationwide delivery. Thank you!`;

    return `https://wa.me/${targetPhone}?text=${encodeURIComponent(text)}`;
  };

  return (
    <ShopContext.Provider
      value={{
        products,
        cart,
        orders,
        wishlist,
        currentPage,
        selectedCategory,
        searchQuery,
        selectedProduct,
        toasts,
        cartDrawerOpen,
        isAdmin,
        setCurrentPage,
        setSelectedCategory,
        setSearchQuery,
        openProductDetail,
        closeProductDetail,
        addToCart,
        removeFromCart,
        updateCartQuantity,
        clearCart,
        setCartDrawerOpen,
        toggleWishlist,
        placeOrder,
        updateOrderStatus,
        setIsAdmin,
        addProduct,
        updateProduct,
        deleteProduct,
        resetProductsToDefault,
        generateWhatsAppLink,
        generateProductWhatsAppLink,
        showToast
      }}
    >
      {children}
    </ShopContext.Provider>
  );
};

export const useShop = () => {
  const context = useContext(ShopContext);
  if (!context) {
    throw new Error('useShop must be used within a ShopProvider');
  }
  return context;
};
