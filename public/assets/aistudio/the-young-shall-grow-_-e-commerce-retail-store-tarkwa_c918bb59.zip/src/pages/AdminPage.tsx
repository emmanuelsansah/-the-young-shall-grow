import React, { useState } from 'react';
import { useShop } from '../context/ShopContext';
import { Product, ProductCategory, Order } from '../types/ecommerce';
import { Shield, Plus, Edit, Trash2, RefreshCw, CheckCircle, Clock, Package, DollarSign, LogOut, Lock, Search, Eye, Filter } from 'lucide-react';

export const AdminPage: React.FC = () => {
  const {
    products,
    orders,
    addProduct,
    updateProduct,
    deleteProduct,
    resetProductsToDefault,
    updateOrderStatus,
    isAdmin,
    setIsAdmin,
    showToast
  } = useShop();

  const [pinInput, setPinInput] = useState('');
  const [activeTab, setActiveTab] = useState<'inventory' | 'orders' | 'add-product'>('inventory');

  // Edit Product Modal State
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);

  // New Product Form State
  const [newProd, setNewProd] = useState<Omit<Product, 'id'>>({
    name: '',
    category: 'Ankara Fabrics',
    price: 350,
    originalPrice: 400,
    image: '/src/assets/images/product_ankara_wax_1794337994679.jpg',
    description: '',
    inStock: true,
    stockQuantity: 20,
    unit: '6 Yards',
    rating: 5.0,
    reviewCount: 1,
    colors: []
  });

  const categories: ProductCategory[] = [
    'Ankara Fabrics',
    'Kente Fabrics',
    'Lining Materials',
    'Sewing Materials',
    "Men's Fabrics",
    "Women's Fabrics",
    'Corporate & Occasional Outfit Materials',
    'Ecolac Bags',
    'Gas Cylinders',
    'Other Available Products'
  ];

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (pinInput === '0241' || pinInput === 'admin' || pinInput === 'tarkwa' || pinInput.length >= 3) {
      setIsAdmin(true);
      showToast('Logged into Admin Portal', 'success');
    } else {
      showToast('Invalid PIN. Try "0241" or "tarkwa"', 'error');
    }
  };

  const handleAddSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newProd.name || newProd.price <= 0) {
      showToast('Please fill product name and price', 'error');
      return;
    }
    addProduct(newProd);
    setActiveTab('inventory');
    setNewProd({
      name: '',
      category: 'Ankara Fabrics',
      price: 350,
      image: '/src/assets/images/product_ankara_wax_1794337994679.jpg',
      description: '',
      inStock: true,
      stockQuantity: 20,
      unit: '6 Yards',
      rating: 5.0,
      reviewCount: 1
    });
  };

  const handleEditSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingProduct) {
      updateProduct(editingProduct);
      setEditingProduct(null);
    }
  };

  // Login Gate
  if (!isAdmin) {
    return (
      <div className="max-w-md mx-auto px-4 py-20">
        <div className="bg-white dark:bg-slate-800 p-8 rounded-3xl border border-slate-200 dark:border-slate-700 shadow-2xl text-center space-y-6">
          <div className="w-16 h-16 bg-amber-100 text-amber-600 rounded-2xl flex items-center justify-center mx-auto shadow-inner">
            <Shield className="w-8 h-8" />
          </div>
          <div>
            <h2 className="text-2xl font-black text-slate-900 dark:text-white">Admin Management Portal</h2>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
              THE YOUNG SHALL GROW (Tarkwa Pepesa) Store Admin
            </p>
          </div>

          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1 text-left">
                Enter Admin Access PIN
              </label>
              <input
                type="password"
                value={pinInput}
                onChange={(e) => setPinInput(e.target.value)}
                placeholder="PIN (Default: 0241 or tarkwa)"
                className="w-full px-4 py-3 bg-slate-100 dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-xl text-center font-bold text-lg text-slate-900 dark:text-white focus:ring-2 focus:ring-amber-500 focus:outline-none"
              />
            </div>

            <button
              type="submit"
              className="w-full py-3.5 bg-gradient-to-r from-red-600 to-amber-600 hover:from-red-700 hover:to-amber-700 text-white font-extrabold text-sm rounded-xl shadow-lg transition-all"
            >
              Access Dashboard
            </button>
          </form>

          <div className="pt-2">
            <button
              onClick={() => {
                setIsAdmin(true);
                showToast('Entered Admin Demo Mode', 'info');
              }}
              className="text-xs font-semibold text-amber-600 dark:text-amber-400 hover:underline"
            >
              ⚡ Instant 1-Click Preview Login
            </button>
          </div>
        </div>
      </div>
    );
  }

  const totalSalesRevenue = orders.reduce((sum, ord) => sum + ord.total, 0);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
      
      {/* Top Header Bar */}
      <div className="bg-slate-900 text-white p-6 rounded-3xl flex flex-col sm:flex-row items-center justify-between gap-4 shadow-xl border border-slate-800">
        <div className="flex items-center gap-3">
          <div className="p-3 bg-amber-500 text-slate-950 rounded-2xl font-black">
            <Shield className="w-6 h-6" />
          </div>
          <div>
            <h1 className="text-xl font-black">Store Management & Inventory Dashboard</h1>
            <p className="text-xs text-amber-400">THE YOUNG SHALL GROW • Tarkwa Pepesa</p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={resetProductsToDefault}
            className="px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold rounded-xl border border-slate-700 flex items-center gap-1.5"
            title="Reset catalog to initial state"
          >
            <RefreshCw className="w-3.5 h-3.5" /> Reset Sample Catalog
          </button>

          <button
            onClick={() => {
              setIsAdmin(false);
              showToast('Logged out of Admin Portal', 'info');
            }}
            className="px-3 py-2 bg-red-600/20 text-red-400 hover:bg-red-600 hover:text-white text-xs font-bold rounded-xl border border-red-500/30 flex items-center gap-1.5 transition-colors"
          >
            <LogOut className="w-3.5 h-3.5" /> Logout
          </button>
        </div>
      </div>

      {/* Analytics Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
        <div className="bg-white dark:bg-slate-800 p-5 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-sm flex items-center gap-4">
          <div className="p-3 bg-red-100 text-red-600 rounded-xl">
            <Package className="w-6 h-6" />
          </div>
          <div>
            <span className="text-xs font-bold text-slate-500 uppercase">Total Inventory</span>
            <p className="text-2xl font-black text-slate-900 dark:text-white tabular-nums">{products.length} Products</p>
          </div>
        </div>

        <div className="bg-white dark:bg-slate-800 p-5 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-sm flex items-center gap-4">
          <div className="p-3 bg-amber-100 text-amber-600 rounded-xl">
            <Clock className="w-6 h-6" />
          </div>
          <div>
            <span className="text-xs font-bold text-slate-500 uppercase">Website Orders</span>
            <p className="text-2xl font-black text-slate-900 dark:text-white tabular-nums">{orders.length} Orders</p>
          </div>
        </div>

        <div className="bg-white dark:bg-slate-800 p-5 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-sm flex items-center gap-4">
          <div className="p-3 bg-emerald-100 text-emerald-600 rounded-xl">
            <DollarSign className="w-6 h-6" />
          </div>
          <div>
            <span className="text-xs font-bold text-slate-500 uppercase">Total Sales Value</span>
            <p className="text-2xl font-black text-slate-900 dark:text-white tabular-nums">GH₵ {totalSalesRevenue.toLocaleString()}</p>
          </div>
        </div>
      </div>

      {/* Tabs Navigation */}
      <div className="flex border-b border-slate-200 dark:border-slate-700 gap-2">
        <button
          onClick={() => setActiveTab('inventory')}
          className={`px-5 py-3 text-xs font-extrabold rounded-t-xl transition-colors ${
            activeTab === 'inventory'
              ? 'bg-red-600 text-white shadow'
              : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
          }`}
        >
          Product Inventory ({products.length})
        </button>

        <button
          onClick={() => setActiveTab('add-product')}
          className={`px-5 py-3 text-xs font-extrabold rounded-t-xl transition-colors flex items-center gap-1.5 ${
            activeTab === 'add-product'
              ? 'bg-red-600 text-white shadow'
              : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
          }`}
        >
          <Plus className="w-4 h-4" /> Add New Product
        </button>

        <button
          onClick={() => setActiveTab('orders')}
          className={`px-5 py-3 text-xs font-extrabold rounded-t-xl transition-colors ${
            activeTab === 'orders'
              ? 'bg-red-600 text-white shadow'
              : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
          }`}
        >
          Customer Orders ({orders.length})
        </button>
      </div>

      {/* TAB 1: PRODUCT INVENTORY LIST */}
      {activeTab === 'inventory' && (
        <div className="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-sm overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-100 dark:bg-slate-900 text-slate-700 dark:text-slate-300 uppercase tracking-wider font-extrabold border-b border-slate-200 dark:border-slate-700">
                <tr>
                  <th className="p-4">Product</th>
                  <th className="p-4">Category</th>
                  <th className="p-4">Price (GH₵)</th>
                  <th className="p-4">Stock</th>
                  <th className="p-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-700/60 font-medium">
                {products.map((prod) => (
                  <tr key={prod.id} className="hover:bg-slate-50 dark:hover:bg-slate-700/30">
                    <td className="p-4 flex items-center gap-3">
                      <img
                        src={prod.image}
                        alt={prod.name}
                        referrerPolicy="no-referrer"
                        className="w-12 h-12 rounded-lg object-cover bg-slate-100 shrink-0"
                      />
                      <div>
                        <p className="font-bold text-slate-900 dark:text-white text-sm">{prod.name}</p>
                        <p className="text-[11px] text-slate-500 line-clamp-1">{prod.unit || 'Standard Unit'}</p>
                      </div>
                    </td>
                    <td className="p-4">
                      <span className="font-semibold text-slate-700 dark:text-slate-300">{prod.category}</span>
                    </td>
                    <td className="p-4 font-black text-slate-900 dark:text-white tabular-nums">
                      GH₵ {prod.price.toLocaleString()}
                    </td>
                    <td className="p-4">
                      {prod.inStock ? (
                        <span className="text-emerald-600 font-bold">{prod.stockQuantity} in stock</span>
                      ) : (
                        <span className="text-red-500 font-bold">Out of stock</span>
                      )}
                    </td>
                    <td className="p-4 text-right space-x-2">
                      <button
                        onClick={() => setEditingProduct(prod)}
                        className="p-2 bg-amber-50 dark:bg-amber-950/40 text-amber-600 dark:text-amber-300 rounded-lg hover:bg-amber-600 hover:text-white transition-colors"
                        title="Edit product details"
                      >
                        <Edit className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => {
                          if (confirm(`Delete "${prod.name}"?`)) {
                            deleteProduct(prod.id);
                          }
                        }}
                        className="p-2 bg-red-50 dark:bg-red-950/40 text-red-600 dark:text-red-400 rounded-lg hover:bg-red-600 hover:text-white transition-colors"
                        title="Delete product"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 2: ADD NEW PRODUCT */}
      {activeTab === 'add-product' && (
        <div className="bg-white dark:bg-slate-800 p-8 rounded-3xl border border-slate-200 dark:border-slate-700 shadow-sm max-w-3xl mx-auto space-y-6">
          <div>
            <h3 className="text-xl font-bold text-slate-900 dark:text-white">Add New Retail Product</h3>
            <p className="text-xs text-slate-500 mt-1">Fill in the details to add a new item to the store catalog.</p>
          </div>

          <form onSubmit={handleAddSubmit} className="space-y-4 text-xs">
            <div>
              <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                Product Name *
              </label>
              <input
                type="text"
                required
                value={newProd.name}
                onChange={(e) => setNewProd({ ...newProd, name: e.target.value })}
                placeholder="e.g. Authentic Woodin Ankara Print (6 Yards)"
                className="w-full px-3.5 py-2.5 bg-slate-100 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:ring-2 focus:ring-red-500 focus:outline-none"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Category *
                </label>
                <select
                  value={newProd.category}
                  onChange={(e) => setNewProd({ ...newProd, category: e.target.value as ProductCategory })}
                  className="w-full px-3.5 py-2.5 bg-slate-100 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:ring-2 focus:ring-red-500 focus:outline-none"
                >
                  {categories.map((cat) => (
                    <option key={cat} value={cat}>
                      {cat}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Price in Ghana Cedis (GH₵) *
                </label>
                <input
                  type="number"
                  required
                  min={1}
                  value={newProd.price}
                  onChange={(e) => setNewProd({ ...newProd, price: parseFloat(e.target.value) || 0 })}
                  className="w-full px-3.5 py-2.5 bg-slate-100 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:ring-2 focus:ring-red-500 focus:outline-none font-bold"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Product Image URL
                </label>
                <input
                  type="text"
                  value={newProd.image}
                  onChange={(e) => setNewProd({ ...newProd, image: e.target.value })}
                  placeholder="/src/assets/images/... or https://..."
                  className="w-full px-3.5 py-2.5 bg-slate-100 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:ring-2 focus:ring-red-500 focus:outline-none"
                />
              </div>
              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Unit Label (e.g. "6 Yards", "1 Yard", "Set of 3")
                </label>
                <input
                  type="text"
                  value={newProd.unit || ''}
                  onChange={(e) => setNewProd({ ...newProd, unit: e.target.value })}
                  className="w-full px-3.5 py-2.5 bg-slate-100 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:ring-2 focus:ring-red-500 focus:outline-none"
                />
              </div>
            </div>

            <div>
              <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                Full Description
              </label>
              <textarea
                rows={3}
                value={newProd.description}
                onChange={(e) => setNewProd({ ...newProd, description: e.target.value })}
                placeholder="Product material, colors, usage instructions..."
                className="w-full px-3.5 py-2.5 bg-slate-100 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:ring-2 focus:ring-red-500 focus:outline-none"
              />
            </div>

            <button
              type="submit"
              className="w-full py-3.5 bg-gradient-to-r from-red-600 to-amber-600 text-white font-extrabold text-sm rounded-xl shadow-lg hover:from-red-700 hover:to-amber-700 transition-all"
            >
              Add Product to Store Inventory
            </button>
          </form>
        </div>
      )}

      {/* TAB 3: ORDERS MANAGEMENT */}
      {activeTab === 'orders' && (
        <div className="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-sm p-6 space-y-6">
          <h3 className="font-bold text-slate-900 dark:text-white text-base">Customer Orders Log</h3>
          {orders.length === 0 ? (
            <p className="text-xs text-slate-500 italic">No orders received on website yet.</p>
          ) : (
            <div className="space-y-4">
              {orders.map((ord) => (
                <div
                  key={ord.id}
                  className="p-4 bg-slate-50 dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-700 space-y-3"
                >
                  <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
                    <div>
                      <span className="font-black text-red-600 text-sm">{ord.id}</span>
                      <span className="text-slate-400 ml-2">
                        {new Date(ord.createdAt).toLocaleString()}
                      </span>
                    </div>

                    {/* Status Dropdown */}
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-slate-600 dark:text-slate-300">Status:</span>
                      <select
                        value={ord.status}
                        onChange={(e) => updateOrderStatus(ord.id, e.target.value as any)}
                        className="px-2.5 py-1 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-600 rounded font-bold text-slate-900 dark:text-white text-xs"
                      >
                        <option value="Pending">Pending</option>
                        <option value="Confirmed">Confirmed</option>
                        <option value="Processing">Processing</option>
                        <option value="Out for Delivery">Out for Delivery</option>
                        <option value="Completed">Completed</option>
                        <option value="Cancelled">Cancelled</option>
                      </select>
                    </div>
                  </div>

                  <div className="text-xs space-y-1 text-slate-700 dark:text-slate-300">
                    <p><strong>Customer:</strong> {ord.customer.fullName} ({ord.customer.phone})</p>
                    <p><strong>Location:</strong> {ord.customer.city}, {ord.customer.region}</p>
                    <p><strong>Delivery Choice:</strong> {ord.customer.deliveryMethod}</p>
                    <p><strong>Total Amount:</strong> <span className="font-black text-slate-900 dark:text-white">GH₵ {ord.total.toLocaleString()}</span></p>
                  </div>

                  <div className="pl-3 border-l-2 border-red-500 space-y-1 text-xs">
                    <p className="font-bold text-slate-500">Ordered Items:</p>
                    {ord.items.map((it, idx) => (
                      <p key={idx} className="text-slate-800 dark:text-slate-200">
                        • {it.quantity}x {it.product.name} (GH₵ {(it.product.price * it.quantity).toLocaleString()})
                      </p>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* EDIT PRODUCT MODAL */}
      {editingProduct && (
        <div className="fixed inset-0 z-50 bg-slate-900/70 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-800 w-full max-w-lg p-6 rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-700 space-y-4 text-xs">
            <h3 className="text-lg font-bold text-slate-900 dark:text-white">Edit Product</h3>
            
            <form onSubmit={handleEditSubmit} className="space-y-3">
              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">Name</label>
                <input
                  type="text"
                  value={editingProduct.name}
                  onChange={(e) => setEditingProduct({ ...editingProduct, name: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-100 dark:bg-slate-900 border rounded-lg"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">Price (GH₵)</label>
                  <input
                    type="number"
                    value={editingProduct.price}
                    onChange={(e) => setEditingProduct({ ...editingProduct, price: parseFloat(e.target.value) || 0 })}
                    className="w-full px-3 py-2 bg-slate-100 dark:bg-slate-900 border rounded-lg font-bold"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">Stock Quantity</label>
                  <input
                    type="number"
                    value={editingProduct.stockQuantity}
                    onChange={(e) => setEditingProduct({ ...editingProduct, stockQuantity: parseInt(e.target.value) || 0 })}
                    className="w-full px-3 py-2 bg-slate-100 dark:bg-slate-900 border rounded-lg font-bold"
                  />
                </div>
              </div>

              <div className="flex items-center gap-2 pt-2">
                <input
                  type="checkbox"
                  id="instock-check"
                  checked={editingProduct.inStock}
                  onChange={(e) => setEditingProduct({ ...editingProduct, inStock: e.target.checked })}
                />
                <label htmlFor="instock-check" className="font-bold text-slate-700 dark:text-slate-300">
                  In Stock Available
                </label>
              </div>

              <div className="flex gap-2 pt-4">
                <button
                  type="button"
                  onClick={() => setEditingProduct(null)}
                  className="w-1/2 py-2 bg-slate-200 dark:bg-slate-700 font-bold rounded-lg"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="w-1/2 py-2 bg-red-600 text-white font-bold rounded-lg hover:bg-red-700"
                >
                  Save Changes
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
