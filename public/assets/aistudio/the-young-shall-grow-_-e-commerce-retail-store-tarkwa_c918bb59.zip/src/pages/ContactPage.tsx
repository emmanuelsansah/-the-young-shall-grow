import React, { useState } from 'react';
import { useShop } from '../context/ShopContext';
import { MapPin, Phone, MessageSquare, Mail, Send, Clock, Truck, ShieldCheck } from 'lucide-react';

export const ContactPage: React.FC = () => {
  const { showToast } = useShop();

  const [form, setForm] = useState({
    name: '',
    phone: '',
    email: '',
    subject: 'General Inquiry',
    message: ''
  });

  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
    showToast('Thank you! Your message has been sent to our Tarkwa team.', 'success');
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-12">
      
      {/* Header */}
      <div className="bg-gradient-to-r from-red-700 via-orange-600 to-amber-600 rounded-3xl p-8 sm:p-12 text-white shadow-xl relative overflow-hidden">
        <div className="relative z-10 max-w-xl space-y-3">
          <span className="text-xs font-extrabold uppercase tracking-widest text-amber-200">
            WE ARE HERE TO SERVE YOU
          </span>
          <h1 className="text-3xl sm:text-5xl font-black">Contact Us</h1>
          <p className="text-xs sm:text-sm text-amber-100 leading-relaxed">
            Visit our physical store in Tarkwa (Pepesa), or contact our sales hotline for instant orders and nationwide delivery inquiries across Ghana.
          </p>
        </div>
      </div>

      {/* Main Grid: Contact Cards & Form */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
        
        {/* Left Column: Direct Action Contact Cards */}
        <div className="lg:col-span-5 space-y-6">
          
          <div className="bg-white dark:bg-slate-800 p-6 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-sm space-y-4">
            <h3 className="font-bold text-slate-900 dark:text-white text-base">Direct Phone Lines</h3>
            <p className="text-xs text-slate-500">Call our customer care representatives anytime:</p>
            <div className="space-y-3 text-sm font-bold">
              <a
                href="tel:0241890996"
                className="flex items-center gap-3 p-3 bg-red-50 dark:bg-slate-700 text-red-700 dark:text-red-300 rounded-xl hover:bg-red-100 transition-colors"
              >
                <Phone className="w-5 h-5" /> 0241890996 (Primary Hotline)
              </a>
              <a
                href="tel:0243276094"
                className="flex items-center gap-3 p-3 bg-amber-50 dark:bg-slate-700 text-amber-800 dark:text-amber-300 rounded-xl hover:bg-amber-100 transition-colors"
              >
                <Phone className="w-5 h-5" /> 0243276094 (Secondary Line)
              </a>
            </div>
          </div>

          <div className="bg-gradient-to-r from-emerald-600 to-teal-700 text-white p-6 rounded-2xl shadow-lg space-y-4">
            <h3 className="font-bold text-base flex items-center gap-2">
              <MessageSquare className="w-5 h-5" /> WhatsApp Ordering
            </h3>
            <p className="text-xs text-emerald-100">
              Send us product photos, fabric yardage requests, or ask for Tarkwa store directions on WhatsApp.
            </p>
            <div className="space-y-2">
              <a
                href="https://wa.me/233241890996"
                target="_blank"
                rel="noreferrer"
                className="w-full py-3 bg-white text-emerald-800 font-extrabold text-xs rounded-xl shadow flex items-center justify-center gap-2 hover:bg-emerald-50 transition-colors"
              >
                <MessageSquare className="w-4 h-4" /> Chat on 0241890996
              </a>
              <a
                href="https://wa.me/233243276094"
                target="_blank"
                rel="noreferrer"
                className="w-full py-2.5 bg-emerald-950/60 hover:bg-emerald-950 text-white font-bold text-xs rounded-xl flex items-center justify-center gap-2 transition-colors"
              >
                <MessageSquare className="w-3.5 h-3.5" /> Chat on 0243276094
              </a>
            </div>
          </div>

          {/* Location & Opening Hours Card */}
          <div className="bg-white dark:bg-slate-800 p-6 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-sm space-y-4">
            <div className="flex items-start gap-3">
              <MapPin className="w-5 h-5 text-red-600 shrink-0 mt-1" />
              <div>
                <h4 className="font-bold text-slate-900 dark:text-white text-sm">Store Address</h4>
                <p className="text-xs text-slate-600 dark:text-slate-400 mt-0.5">
                  THE YOUNG SHALL GROW, Tarkwa (Pepesa), Western Region, Ghana.
                </p>
              </div>
            </div>

            <div className="flex items-start gap-3 pt-2 border-t border-slate-100 dark:border-slate-700">
              <Clock className="w-5 h-5 text-amber-500 shrink-0 mt-1" />
              <div>
                <h4 className="font-bold text-slate-900 dark:text-white text-sm">Opening Hours</h4>
                <p className="text-xs text-slate-600 dark:text-slate-400 mt-0.5">
                  Monday – Saturday: 7:00 AM – 7:00 PM<br />
                  Sunday: Closed (WhatsApp orders active)
                </p>
              </div>
            </div>
          </div>

        </div>

        {/* Right Column: Contact Message Form */}
        <div className="lg:col-span-7 bg-white dark:bg-slate-800 p-8 rounded-3xl border border-slate-200 dark:border-slate-700 shadow-sm space-y-6">
          <div>
            <h3 className="text-xl font-bold text-slate-900 dark:text-white">Send Us a Direct Message</h3>
            <p className="text-xs text-slate-500 mt-1">
              Have questions about fabric stock, bulk order discounts, gas cylinder refills, or Ecolac bag specs? Fill out the form below.
            </p>
          </div>

          {submitted ? (
            <div className="p-8 bg-emerald-50 dark:bg-slate-700 text-center rounded-2xl border border-emerald-200 dark:border-slate-600 space-y-3">
              <ShieldCheck className="w-12 h-12 text-emerald-600 mx-auto" />
              <h4 className="text-lg font-bold text-emerald-900 dark:text-emerald-200">Message Received!</h4>
              <p className="text-xs text-emerald-700 dark:text-emerald-300 max-w-md mx-auto">
                Thank you for contacting THE YOUNG SHALL GROW. Our Tarkwa representative will reach out to you via phone or email shortly.
              </p>
              <button
                onClick={() => setSubmitted(false)}
                className="px-6 py-2 bg-emerald-600 text-white font-bold text-xs rounded-xl hover:bg-emerald-700"
              >
                Send Another Message
              </button>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                    Your Full Name *
                  </label>
                  <input
                    type="text"
                    required
                    value={form.name}
                    onChange={(e) => setForm({ ...form, name: e.target.value })}
                    placeholder="e.g. Ama Osei"
                    className="w-full px-3 py-2.5 bg-slate-100 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:ring-2 focus:ring-red-500 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                    Phone Number *
                  </label>
                  <input
                    type="tel"
                    required
                    value={form.phone}
                    onChange={(e) => setForm({ ...form, phone: e.target.value })}
                    placeholder="024XXXXXXX"
                    className="w-full px-3 py-2.5 bg-slate-100 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:ring-2 focus:ring-red-500 focus:outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                    Email Address
                  </label>
                  <input
                    type="email"
                    value={form.email}
                    onChange={(e) => setForm({ ...form, email: e.target.value })}
                    placeholder="ama.osei@gmail.com"
                    className="w-full px-3 py-2.5 bg-slate-100 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:ring-2 focus:ring-red-500 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                    Inquiry Subject
                  </label>
                  <select
                    value={form.subject}
                    onChange={(e) => setForm({ ...form, subject: e.target.value })}
                    className="w-full px-3 py-2.5 bg-slate-100 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:ring-2 focus:ring-red-500 focus:outline-none"
                  >
                    <option value="General Inquiry">General Product Inquiry</option>
                    <option value="Fabric Yardage Order">Ankara / Kente Yardage Order</option>
                    <option value="Tailor Wholesale Partnership">Tailor Wholesale Partnership</option>
                    <option value="Ecolac Luggage Query">Ecolac Luggage Query</option>
                    <option value="Gas Cylinder Delivery">Gas Cylinder Delivery</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Your Message / Product Request *
                </label>
                <textarea
                  rows={4}
                  required
                  value={form.message}
                  onChange={(e) => setForm({ ...form, message: e.target.value })}
                  placeholder="Describe what you are looking for..."
                  className="w-full px-3 py-2.5 bg-slate-100 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white focus:ring-2 focus:ring-red-500 focus:outline-none"
                />
              </div>

              <button
                type="submit"
                className="w-full py-3 bg-gradient-to-r from-red-600 to-amber-600 hover:from-red-700 hover:to-amber-700 text-white font-extrabold text-sm rounded-xl shadow-lg flex items-center justify-center gap-2 transition-all"
              >
                <Send className="w-4 h-4" /> Send Message
              </button>
            </form>
          )}

          {/* Delivery Timelines Table */}
          <div className="pt-6 border-t border-slate-100 dark:border-slate-700">
            <h4 className="font-bold text-slate-900 dark:text-white text-xs mb-3 flex items-center gap-1.5">
              <Truck className="w-4 h-4 text-red-600" /> Ghana Delivery Estimated Timelines
            </h4>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-[11px] text-center">
              <div className="p-2 bg-slate-50 dark:bg-slate-900 rounded-lg">
                <p className="font-bold text-slate-800 dark:text-slate-200">Tarkwa Pepesa</p>
                <p className="text-emerald-600 font-semibold">Same Day Pickup / Delivery</p>
              </div>
              <div className="p-2 bg-slate-50 dark:bg-slate-900 rounded-lg">
                <p className="font-bold text-slate-800 dark:text-slate-200">Takoradi / Sekondi</p>
                <p className="text-slate-500">24 Hours (STC / VIP)</p>
              </div>
              <div className="p-2 bg-slate-50 dark:bg-slate-900 rounded-lg">
                <p className="font-bold text-slate-800 dark:text-slate-200">Accra / Kumasi</p>
                <p className="text-slate-500">1 – 2 Days</p>
              </div>
              <div className="p-2 bg-slate-50 dark:bg-slate-900 rounded-lg">
                <p className="font-bold text-slate-800 dark:text-slate-200">Other Regions</p>
                <p className="text-slate-500">2 – 3 Days</p>
              </div>
            </div>
          </div>
        </div>

      </div>
    </div>
  );
};
