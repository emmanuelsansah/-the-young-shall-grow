import React from 'react';
import { useShop } from '../context/ShopContext';
import { ProductCard } from '../components/ProductCard';
import { ProductCategory } from '../types/ecommerce';
import { ArrowRight, ShoppingBag, ShieldCheck, Truck, Phone, MessageSquare, Star, CheckCircle, Sparkles, MapPin } from 'lucide-react';

export const HomePage: React.FC = () => {
  const { products, setCurrentPage, setSelectedCategory, openProductDetail } = useShop();

  const featuredProducts = products.filter((p) => p.featured).slice(0, 4);
  const bestSellers = products.filter((p) => p.bestSeller).slice(0, 4);
  const newArrivals = products.filter((p) => p.newArrival).slice(0, 4);

  const categoryHighlights: { name: ProductCategory; image: string; desc: string }[] = [
    {
      name: 'Ankara Fabrics',
      image: '/src/assets/images/product_ankara_wax_1794337994679.jpg',
      desc: 'Genuine GTP & High-Target Super Flash Ankara wax prints in vibrant 6-yard pieces.'
    },
    {
      name: 'Kente Fabrics',
      image: '/src/assets/images/product_kente_weave_1794337995525.jpg',
      desc: 'Royal handwoven Ghanaian Kente cloth sets for weddings and grand ceremonies.'
    },
    {
      name: 'Ecolac Bags',
      image: '/src/assets/images/product_ecolac_luggage_1794337995534.jpg',
      desc: 'Original heavy-duty hardshell Ecolac spinner suitcase sets and executive backpacks.'
    },
    {
      name: 'Gas Cylinders',
      image: '/src/assets/images/product_gas_cylinder_1794337995354.jpg',
      desc: 'NPA safety certified 6kg and 12.5kg LPG gas cylinders with brass valves.'
    },
    {
      name: "Men's Fabrics",
      image: 'https://images.unsplash.com/photo-1598033129183-c4f50c736f10?auto=format&fit=crop&q=80&w=800',
      desc: 'Italian Cashmere wool, Senator suit fabric, and kaftan materials for men.'
    },
    {
      name: 'Sewing Materials',
      image: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&q=80&w=800',
      desc: 'Tailoring threads, scissors, lining satin, zips, and professional sewing gear.'
    }
  ];

  return (
    <div className="space-y-16 pb-16">
      
      {/* 1. HERO SECTION */}
      <section className="relative bg-slate-900 text-white overflow-hidden rounded-b-3xl sm:rounded-b-[2.5rem] shadow-xl">
        {/* Backdrop Image with Scrim Overlay */}
        <div className="absolute inset-0 z-0">
          <img
            src="/src/assets/images/hero_ankara_fabric_ghana_1794337995124.jpg"
            alt="The Young Shall Grow Tarkwa Showroom"
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover object-center scale-105 filter brightness-[0.45]"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-slate-950/90 via-slate-950/70 to-transparent" />
        </div>

        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 sm:py-28 lg:py-32 grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          
          <div className="lg:col-span-8 space-y-6">
            
            {/* Location Pill */}
            <div className="inline-flex items-center gap-2 px-3 py-1 bg-red-600/90 backdrop-blur-md rounded-full text-xs font-bold uppercase tracking-wider text-white shadow-md">
              <MapPin className="w-3.5 h-3.5 text-amber-300" />
              <span>Tarkwa (Pepesa) • Ghana</span>
            </div>

            {/* Main Hero Title */}
            <h1 className="text-3xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-balance leading-none">
              THE YOUNG SHALL GROW
            </h1>

            {/* Business Slogan */}
            <p className="text-lg sm:text-2xl font-semibold text-amber-400 italic">
              "Where Quality Meets Affordability. Your Comfort, Our Promise."
            </p>

            <p className="text-sm sm:text-base text-slate-300 max-w-2xl leading-relaxed">
              Ghana's trusted retail destination for premium Ankara wax prints, royal Kente fabrics, tailor sewing materials, durable Ecolac travel luggage, and NPA certified gas cylinders.
            </p>

            {/* Action Buttons */}
            <div className="pt-4 flex flex-wrap items-center gap-3">
              <button
                onClick={() => {
                  setSelectedCategory('All');
                  setCurrentPage('shop');
                }}
                className="px-6 py-3.5 bg-gradient-to-r from-red-600 to-amber-600 hover:from-red-700 hover:to-amber-700 text-white font-extrabold text-sm rounded-xl shadow-xl hover:shadow-red-900/30 flex items-center gap-2 transition-all active:scale-95"
              >
                <ShoppingBag className="w-5 h-5" /> Shop Now
              </button>

              <button
                onClick={() => {
                  setSelectedCategory('All');
                  setCurrentPage('shop');
                }}
                className="px-6 py-3.5 bg-white/10 hover:bg-white/20 backdrop-blur-md text-white font-bold text-sm rounded-xl border border-white/20 flex items-center gap-2 transition-all"
              >
                Explore Products <ArrowRight className="w-4 h-4" />
              </button>

              <button
                onClick={() => setCurrentPage('contact')}
                className="px-6 py-3.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-sm rounded-xl shadow-lg flex items-center gap-2 transition-all"
              >
                <Phone className="w-4 h-4" /> Contact Us
              </button>
            </div>

            {/* Direct Phone Numbers */}
            <div className="pt-2 flex items-center gap-4 text-xs text-slate-300 font-medium">
              <span>Direct Hotline:</span>
              <a href="tel:0241890996" className="font-bold text-amber-300 hover:underline">0241890996</a>
              <span>/</span>
              <a href="tel:0243276094" className="font-bold text-amber-300 hover:underline">0243276094</a>
            </div>
          </div>
        </div>
      </section>

      {/* 2. VALUE PROPOSITIONS STRIP */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="p-4 bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-sm flex items-center gap-3">
            <div className="p-3 bg-red-100 text-red-600 rounded-xl">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <h4 className="font-bold text-xs text-slate-900 dark:text-white">Affordable Prices</h4>
              <p className="text-[11px] text-slate-500">Unbeatable value in Ghana</p>
            </div>
          </div>

          <div className="p-4 bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-sm flex items-center gap-3">
            <div className="p-3 bg-amber-100 text-amber-600 rounded-xl">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h4 className="font-bold text-xs text-slate-900 dark:text-white">Quality Products</h4>
              <p className="text-[11px] text-slate-500">100% Authentic materials</p>
            </div>
          </div>

          <div className="p-4 bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-sm flex items-center gap-3">
            <div className="p-3 bg-emerald-100 text-emerald-600 rounded-xl">
              <Truck className="w-5 h-5" />
            </div>
            <div>
              <h4 className="font-bold text-xs text-slate-900 dark:text-white">Nationwide Delivery</h4>
              <p className="text-[11px] text-slate-500">Fast shipping across Ghana</p>
            </div>
          </div>

          <div className="p-4 bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-sm flex items-center gap-3">
            <div className="p-3 bg-blue-100 text-blue-600 rounded-xl">
              <MessageSquare className="w-5 h-5" />
            </div>
            <div>
              <h4 className="font-bold text-xs text-slate-900 dark:text-white">WhatsApp Ordering</h4>
              <p className="text-[11px] text-slate-500">Fast response on 0241890996</p>
            </div>
          </div>
        </div>
      </section>

      {/* 3. FEATURED PRODUCT CATEGORIES */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 border-b border-slate-200 dark:border-slate-800 pb-4">
          <div>
            <span className="text-xs font-extrabold uppercase tracking-widest text-red-600">
              EXPLORE OUR COLLECTIONS
            </span>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white mt-1">
              Featured Product Categories
            </h2>
          </div>
          <button
            onClick={() => {
              setSelectedCategory('All');
              setCurrentPage('shop');
            }}
            className="text-xs font-bold text-red-600 hover:text-red-700 flex items-center gap-1 group"
          >
            View All Categories <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {categoryHighlights.map((cat, idx) => (
            <div
              key={idx}
              onClick={() => {
                setSelectedCategory(cat.name);
                setCurrentPage('shop');
              }}
              className="group relative bg-slate-900 rounded-2xl overflow-hidden shadow-md hover:shadow-2xl transition-all cursor-pointer aspect-[16/10]"
            >
              <img
                src={cat.image}
                alt={cat.name}
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 opacity-80 group-hover:opacity-75"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/40 to-transparent p-6 flex flex-col justify-end">
                <span className="text-xs font-bold text-amber-400 uppercase tracking-wider">Category</span>
                <h3 className="text-xl font-extrabold text-white group-hover:text-amber-300 transition-colors">
                  {cat.name}
                </h3>
                <p className="text-xs text-slate-300 mt-1 line-clamp-2">{cat.desc}</p>
                <div className="mt-3 flex items-center gap-1 text-xs font-bold text-white group-hover:translate-x-1 transition-transform">
                  <span>Shop Collection</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* 4. BEST SELLING PRODUCTS */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 border-b border-slate-200 dark:border-slate-800 pb-4">
          <div>
            <span className="text-xs font-extrabold uppercase tracking-widest text-amber-600">
              POPULAR CHOICE IN TARKWA
            </span>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white mt-1">
              Best-Selling Products
            </h2>
          </div>
          <button
            onClick={() => {
              setSelectedCategory('All');
              setCurrentPage('shop');
            }}
            className="text-xs font-bold text-red-600 hover:text-red-700 flex items-center gap-1"
          >
            Browse Full Shop Catalog <ArrowRight className="w-4 h-4" />
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {bestSellers.map((prod) => (
            <ProductCard key={prod.id} product={prod} />
          ))}
        </div>
      </section>

      {/* 5. NEW ARRIVALS */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 border-b border-slate-200 dark:border-slate-800 pb-4">
          <div>
            <span className="text-xs font-extrabold uppercase tracking-widest text-emerald-600">
              FRESH IN STORE
            </span>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white mt-1">
              New Arrivals
            </h2>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {newArrivals.map((prod) => (
            <ProductCard key={prod.id} product={prod} />
          ))}
        </div>
      </section>

      {/* 6. WHY CHOOSE US SECTION */}
      <section className="bg-slate-100 dark:bg-slate-900/60 py-16 border-y border-slate-200 dark:border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
          <div className="text-center max-w-2xl mx-auto space-y-2">
            <span className="text-xs font-extrabold uppercase tracking-widest text-red-600">OUR COMMITMENT</span>
            <h2 className="text-3xl font-extrabold text-slate-900 dark:text-white">
              Why Choose THE YOUNG SHALL GROW?
            </h2>
            <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400">
              We take pride in serving Tarkwa, Western Region, and all of Ghana with premium products at prices you can trust.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-white dark:bg-slate-800 p-6 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-sm space-y-3">
              <div className="w-12 h-12 rounded-xl bg-red-100 text-red-600 flex items-center justify-center font-bold text-xl">
                01
              </div>
              <h3 className="text-lg font-bold text-slate-900 dark:text-white">Affordable Prices</h3>
              <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
                We source directly to eliminate unnecessary markups. Quality fabrics and retail supplies without breaking your budget.
              </p>
            </div>

            <div className="bg-white dark:bg-slate-800 p-6 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-sm space-y-3">
              <div className="w-12 h-12 rounded-xl bg-amber-100 text-amber-600 flex items-center justify-center font-bold text-xl">
                02
              </div>
              <h3 className="text-lg font-bold text-slate-900 dark:text-white">Quality Guarantee</h3>
              <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
                From 100% cotton GTP Ankara to unbreakable Ecolac suitcases and NPA certified gas cylinders, every item is thoroughly verified.
              </p>
            </div>

            <div className="bg-white dark:bg-slate-800 p-6 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-sm space-y-3">
              <div className="w-12 h-12 rounded-xl bg-emerald-100 text-emerald-600 flex items-center justify-center font-bold text-xl">
                03
              </div>
              <h3 className="text-lg font-bold text-slate-900 dark:text-white">Reliable Service & Delivery</h3>
              <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
                Located right in Tarkwa (Pepesa), we offer fast local store pick-up and prompt parcel delivery to Accra, Kumasi, Takoradi, and all regions.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* 7. TESTIMONIALS */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        <div className="text-center max-w-xl mx-auto space-y-2">
          <span className="text-xs font-extrabold uppercase tracking-widest text-amber-600">CUSTOMER REVIEWS</span>
          <h2 className="text-3xl font-extrabold text-slate-900 dark:text-white">
            Trusted by Tailors & Households
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="p-6 bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-sm space-y-4">
            <div className="flex text-amber-400 gap-1">
              {[...Array(5)].map((_, i) => (
                <Star key={i} className="w-4 h-4 fill-current" />
              ))}
            </div>
            <p className="text-xs text-slate-600 dark:text-slate-300 italic">
              "The Young Shall Grow is my primary source for Ankara and Cashmere fabrics for my fashion design workshop in Tarkwa. Their GTP prints are 100% original and customer service on WhatsApp is fast!"
            </p>
            <div className="pt-2 border-t border-slate-100 dark:border-slate-700">
              <p className="font-bold text-xs text-slate-900 dark:text-white">Master Tailor Emmanuel Appiah</p>
              <p className="text-[11px] text-slate-400">Fashion Designer, Tarkwa Pepesa</p>
            </div>
          </div>

          <div className="p-6 bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-sm space-y-4">
            <div className="flex text-amber-400 gap-1">
              {[...Array(5)].map((_, i) => (
                <Star key={i} className="w-4 h-4 fill-current" />
              ))}
            </div>
            <p className="text-xs text-slate-600 dark:text-slate-300 italic">
              "Bought the 3-piece Ecolac travel bag set for my daughter going to UMaT university. Solid heavy duty quality, wheels rotate smoothly, and the price was much better than Accra stores."
            </p>
            <div className="pt-2 border-t border-slate-100 dark:border-slate-700">
              <p className="font-bold text-xs text-slate-900 dark:text-white">Mrs. Grace Mensah</p>
              <p className="text-[11px] text-slate-400">Takoradi, Ghana</p>
            </div>
          </div>

          <div className="p-6 bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-sm space-y-4">
            <div className="flex text-amber-400 gap-1">
              {[...Array(5)].map((_, i) => (
                <Star key={i} className="w-4 h-4 fill-current" />
              ))}
            </div>
            <p className="text-xs text-slate-600 dark:text-slate-300 italic">
              "Ordered a 12.5kg gas cylinder and handwoven royal Kente cloth for my engagement ceremony. Arrived in perfect condition with fast delivery!"
            </p>
            <div className="pt-2 border-t border-slate-100 dark:border-slate-700">
              <p className="font-bold text-xs text-slate-900 dark:text-white">Kofi Owusu</p>
              <p className="text-[11px] text-slate-400">Kumasi, Ghana</p>
            </div>
          </div>
        </div>
      </section>

      {/* 8. WHATSAPP BANNER */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-gradient-to-r from-emerald-600 via-teal-700 to-slate-900 rounded-3xl p-8 sm:p-12 text-white flex flex-col md:flex-row items-center justify-between gap-8 shadow-2xl">
          <div className="space-y-3 text-center md:text-left">
            <div className="inline-flex items-center gap-2 px-3 py-1 bg-white/20 backdrop-blur-md rounded-full text-xs font-bold text-emerald-200">
              <MessageSquare className="w-4 h-4" /> Direct Instant Ordering
            </div>
            <h2 className="text-2xl sm:text-4xl font-extrabold">Need Quick Assistance or Custom Fabric Orders?</h2>
            <p className="text-xs sm:text-sm text-emerald-100 max-w-xl">
              Chat directly with our store representatives on WhatsApp for price quotes, bulk tailor orders, or immediate Tarkwa delivery.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row gap-3 w-full md:w-auto shrink-0">
            <a
              href="https://wa.me/233241890996"
              target="_blank"
              rel="noreferrer"
              className="px-6 py-3.5 bg-white text-emerald-800 font-extrabold text-xs sm:text-sm rounded-xl shadow-lg hover:bg-emerald-50 transition-colors flex items-center justify-center gap-2"
            >
              <MessageSquare className="w-4 h-4" /> WhatsApp 0241890996
            </a>
            <a
              href="https://wa.me/233243276094"
              target="_blank"
              rel="noreferrer"
              className="px-6 py-3.5 bg-emerald-950/80 hover:bg-emerald-950 text-white font-bold text-xs sm:text-sm rounded-xl border border-emerald-400/30 transition-colors flex items-center justify-center gap-2"
            >
              <MessageSquare className="w-4 h-4" /> WhatsApp 0243276094
            </a>
          </div>
        </div>
      </section>

    </div>
  );
};
