import React from 'react';
import { useShop } from '../context/ShopContext';
import { MapPin, Award, Heart, ShieldCheck, Truck, Phone, MessageSquare, Scissors, Users } from 'lucide-react';

export const AboutPage: React.FC = () => {
  const { setCurrentPage, setSelectedCategory } = useShop();

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-16">
      
      {/* Hero Header */}
      <div className="bg-gradient-to-r from-red-700 via-orange-600 to-amber-600 rounded-3xl p-8 sm:p-14 text-white shadow-xl relative overflow-hidden">
        <div className="relative z-10 max-w-2xl space-y-4">
          <div className="inline-flex items-center gap-2 px-3 py-1 bg-white/20 backdrop-blur-md rounded-full text-xs font-bold uppercase tracking-wider text-amber-200">
            <MapPin className="w-3.5 h-3.5" /> Tarkwa (Pepesa), Ghana
          </div>
          <h1 className="text-3xl sm:text-5xl font-black">THE YOUNG SHALL GROW</h1>
          <p className="text-lg sm:text-xl font-semibold text-amber-200 italic">
            "Where Quality Meets Affordability. Your Comfort, Our Promise."
          </p>
          <p className="text-xs sm:text-sm text-amber-100 leading-relaxed">
            Established with a commitment to providing Ghanaian households, tailors, fashion designers, and travelers with top-notch fabrics, durable Ecolac luggage, sewing materials, and safety certified gas cylinders.
          </p>
        </div>
      </div>

      {/* Story & Mission Split */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
        <div className="space-y-6">
          <span className="text-xs font-extrabold uppercase tracking-widest text-red-600">OUR STORY & FOUNDATION</span>
          <h2 className="text-3xl font-black text-slate-900 dark:text-white">
            Serving Tarkwa Pepesa with Pride & Integrity
          </h2>
          <p className="text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
            At <strong>THE YOUNG SHALL GROW</strong>, we believe every customer deserves authentic quality without overpaying. What started as a local retail shop in Tarkwa Pepesa has grown into a nationwide brand supplying genuine GTP Ankara wax prints, royal handwoven Kente, high-grade lining fabrics, sewing supplies, Ecolac travel suitcases, and LPG gas cylinders.
          </p>
          <p className="text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
            We work hand-in-hand with master tailors, fashion designers, students, and families across the Western Region and Ghana to ensure prompt delivery, fair pricing, and long-lasting satisfaction.
          </p>

          <div className="pt-4 grid grid-cols-2 gap-4">
            <div className="p-4 bg-slate-50 dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700">
              <span className="text-2xl font-black text-red-600">100%</span>
              <p className="text-xs font-bold text-slate-700 dark:text-slate-300 mt-1">Authentic GTP Fabrics</p>
            </div>
            <div className="p-4 bg-slate-50 dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700">
              <span className="text-2xl font-black text-amber-600">16</span>
              <p className="text-xs font-bold text-slate-700 dark:text-slate-300 mt-1">Regions Delivered in Ghana</p>
            </div>
          </div>
        </div>

        <div className="relative rounded-3xl overflow-hidden shadow-2xl bg-slate-900 aspect-square sm:aspect-[4/3]">
          <img
            src="/src/assets/images/hero_ankara_fabric_ghana_1794337995124.jpg"
            alt="The Young Shall Grow Tarkwa Showroom"
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover"
          />
        </div>
      </div>

      {/* Tailor & Designer Partnership Program */}
      <section className="bg-gradient-to-r from-slate-900 via-slate-850 to-slate-900 rounded-3xl p-8 sm:p-12 text-white space-y-8 shadow-xl">
        <div className="max-w-2xl space-y-3">
          <div className="inline-flex items-center gap-2 px-3 py-1 bg-amber-500/20 text-amber-400 rounded-full text-xs font-bold uppercase tracking-wider">
            <Scissors className="w-4 h-4" /> Tailor & Designer Discount Hub
          </div>
          <h2 className="text-2xl sm:text-4xl font-black">Special Wholesale Pricing for Ghanaian Tailors & Designers</h2>
          <p className="text-xs sm:text-sm text-slate-300">
            Are you a tailor or fashion designer in Tarkwa, Takoradi, Kumasi, or Accra? Partner with us for bulk orders of Ankara rolls, lining materials, threads, and zips at discounted rates.
          </p>
        </div>

        <div className="flex flex-wrap gap-4">
          <a
            href="https://wa.me/233241890996?text=Hello!%20I%20am%20a%20tailor/designer%20interested%20in%20wholesale%20fabric%20orders."
            target="_blank"
            rel="noreferrer"
            className="px-6 py-3.5 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs sm:text-sm rounded-xl shadow-lg flex items-center gap-2 transition-all"
          >
            <MessageSquare className="w-4 h-4" /> Join Tailor Wholesale Hub (0241890996)
          </a>
          <button
            onClick={() => {
              setSelectedCategory('Ankara Fabrics');
              setCurrentPage('shop');
            }}
            className="px-6 py-3.5 bg-white/10 hover:bg-white/20 text-white font-bold text-xs sm:text-sm rounded-xl border border-white/20 transition-all"
          >
            Explore Fabric Collections
          </button>
        </div>
      </section>

    </div>
  );
};
