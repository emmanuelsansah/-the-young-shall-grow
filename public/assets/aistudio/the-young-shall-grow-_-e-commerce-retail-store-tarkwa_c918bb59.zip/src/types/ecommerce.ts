export type ProductCategory = 
  | 'Ankara Fabrics'
  | 'Kente Fabrics'
  | 'Lining Materials'
  | 'Sewing Materials'
  | "Men's Fabrics"
  | "Women's Fabrics"
  | 'Corporate & Occasional Outfit Materials'
  | 'Ecolac Bags'
  | 'Gas Cylinders'
  | 'Other Available Products';

export interface Product {
  id: string;
  name: string;
  category: ProductCategory;
  price: number; // In GH₵
  originalPrice?: number; // In GH₵ for discount callout
  image: string;
  additionalImages?: string[];
  description: string;
  features?: string[];
  inStock: boolean;
  stockQuantity: number;
  featured?: boolean;
  bestSeller?: boolean;
  newArrival?: boolean;
  unit?: string; // e.g. "6 Yards", "1 Yard", "Set of 3", "Piece", "12.5kg"
  rating: number;
  reviewCount: number;
  colors?: string[];
}

export interface CartItem {
  product: Product;
  quantity: number;
  selectedColor?: string;
}

export interface CustomerDetails {
  fullName: string;
  phone: string;
  whatsappPhone: string;
  deliveryAddress: string;
  region: string;
  city: string;
  deliveryMethod: 'Tarkwa Pick-Up' | 'Tarkwa Home Delivery' | 'Nationwide Ghana Shipping (STC/VIP Bus)' | 'Express Doorstep Courier';
  paymentMethod: 'Cash on Delivery / Pickup' | 'Mobile Money (MTN / Telecel / AT)' | 'Bank Transfer';
  orderNotes?: string;
}

export interface Order {
  id: string;
  createdAt: string;
  items: CartItem[];
  customer: CustomerDetails;
  subtotal: number;
  deliveryFee: number;
  total: number;
  status: 'Pending' | 'Confirmed' | 'Processing' | 'Out for Delivery' | 'Completed' | 'Cancelled';
}

export type PageView = 'home' | 'shop' | 'product-detail' | 'cart' | 'about' | 'contact' | 'admin';
