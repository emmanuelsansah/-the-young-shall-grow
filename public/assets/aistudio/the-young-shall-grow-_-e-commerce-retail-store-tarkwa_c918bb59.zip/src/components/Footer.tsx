import React from 'react';
import { MapPin, Phone, MessageSquare, Truck, ShieldCheck, Heart, Award, Clock } from 'lucide-react';
import { useShop } from '../context/ShopContext';
import { ProductCategory } from '../types/ecommerce';

export const Footer: React.FC = () => {
  const { setCurrentPage, setSelectedCategory } = useShop();

  const categories: ProductCategory[] = [
    'Ankara Fabrics',
    'Kente Fabrics',
    'Lining Materials',
    'Sewing Materials',
    "Men's Fabrics",
    "Women's Fabrics",
    'Corporate & Occasional Outfit Materials',
    'Ecolac Bags',
    'Gas Cylinders'
  ];

  return (
    <footer className="bg-slate-950 text-slate-300 pt-16 pb-8 border-t-4 border-red-600">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Value Trust Strip */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 pb-12 border-b border-slate-800">
          <div className="flex items-center gap-4 p-4 rounded-2xl bg-slate-900/60 border border-slate-800">
            <div className="p-3 bg-red-600/20 text-red-500 rounded-xl">
              <Award className="w-6 h-6" />
            </div>
            <div>
              <h4 className="font-bold text-white text-sm">Quality Meets Affordability</h4>
              <p className="text-xs text-slate-400">Guaranteed top tier products in Ghana</p>
            </div>
          </div>

          <div className="flex items-center gap-4 p-4 rounded-2xl bg-slate-900/60 border border-slate-800">
            <div className="p-3 bg-amber-600/20 text-amber-500 rounded-xl">
              <Truck className="w-6 h-6" />
            </div>
            <div>
              <h4 className="font-bold text-white text-sm">Nationwide Delivery</h4>
              <p className="text-xs text-slate-400">Delivered across all 16 regions</p>
            </div>
          </div>

          <div className="flex items-center gap-4 p-4 rounded-2xl bg-slate-900/60 border border-slate-800">
            <div className="p-3 bg-emerald-600/20 text-emerald-500 rounded-xl">
              <MessageSquare className="w-6 h-6" />
            </div>
            <div>
              <h4 className="font-bold text-white text-sm">WhatsApp Fast Order</h4>
              <p className="text-xs text-slate-400">Instant chat on 0241890996</p>
            </div>
          </div>

          <div className="flex items-center gap-4 p-4 rounded-2xl bg-slate-900/60 border border-slate-800">
            <div className="p-3 bg-blue-600/20 text-blue-500 rounded-xl">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
              <h4 className="font-bold text-white text-sm">Trusted Local Retailer</h4>
              <p className="text-xs text-slate-400">Based in Tarkwa (Pepesa), Ghana</p>
            </div>
          </div>
        </div>

        {/* Main Footer Links */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10 py-12">
          
          {/* Col 1: Brand Info */}
          <div className="lg:col-span-2 space-y-4">
            <div className="flex items-center gap-2">
              <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-red-600 to-amber-500 flex items-center justify-center text-white font-black text-lg">
                Y
              </div>
              <span className="text-xl font-extrabold text-white tracking-tight">
                THE YOUNG SHALL GROW
              </span>
            </div>
            <p className="text-xs text-amber-400 italic font-semibold">
              "Where Quality Meets Affordability. Your Comfort, Our Promise."
            </p>
            <p className="text-xs text-slate-400 leading-relaxed max-w-sm">
              Your premier retail destination in Tarkwa (Pepesa), Ghana for authentic Ghanaian Ankara fabrics, royal Kente cloth, lining materials, tailor supplies, Ecolac travel luggage, and NPA certified LPG gas cylinders.
            </p>
            
            <div className="pt-2 flex flex-col gap-2 text-xs">
              <a
                href="https://wa.me/233241890996"
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center gap-2 px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl transition-colors w-fit"
              >
                <MessageSquare className="w-4 h-4" /> WhatsApp Order (0241890996)
              </a>
            </div>
          </div>

          {/* Col 2: Quick Links */}
          <div className="space-y-3">
            <h4 className="text-sm font-bold text-white uppercase tracking-wider">Quick Navigation</h4>
            <ul className="space-y-2 text-xs">
              <li>
                <button onClick={() => { setCurrentPage('home'); window.scrollTo(0, 0); }} className="hover:text-red-400 transition-colors">
                  Home Overview
                </button>
              </li>
              <li>
                <button onClick={() => { setSelectedCategory('All'); setCurrentPage('shop'); window.scrollTo(0, 0); }} className="hover:text-red-400 transition-colors">
                  Full Store Catalog
                </button>
              </li>
              <li>
                <button onClick={() => { setCurrentPage('about'); window.scrollTo(0, 0); }} className="hover:text-red-400 transition-colors">
                  About Our Business
                </button>
              </li>
              <li>
                <button onClick={() => { setCurrentPage('contact'); window.scrollTo(0, 0); }} className="hover:text-red-400 transition-colors">
                  Contact & Location
                </button>
              </li>
              <li>
                <button onClick={() => { setCurrentPage('admin'); window.scrollTo(0, 0); }} className="hover:text-red-400 transition-colors">
                  Admin Management
                </button>
              </li>
            </ul>
          </div>

          {/* Col 3: Shop Categories */}
          <div className="space-y-3">
            <h4 className="text-sm font-bold text-white uppercase tracking-wider">Product Categories</h4>
            <ul className="space-y-1.5 text-xs">
              {categories.slice(0, 7).map((cat) => (
                <li key={cat}>
                  <button
                    onClick={() => {
                      setSelectedCategory(cat);
                      setCurrentPage('shop');
                      window.scrollTo(0, 0);
                    }}
                    className="hover:text-amber-400 transition-colors"
                  >
                    • {cat}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Col 4: Store Location & Contact */}
          <div className="space-y-3">
            <h4 className="text-sm font-bold text-white uppercase tracking-wider">Store Location</h4>
            <div className="space-y-2.5 text-xs text-slate-300">
              <div className="flex items-start gap-2">
                <MapPin className="w-4 h-4 text-red-500 shrink-0 mt-0.5" />
                <span>Tarkwa (Pepesa), Western Region, Ghana</span>
              </div>
              <div className="flex items-start gap-2">
                <Phone className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />
                <div>
                  <p>0241890996</p>
                  <p>0243276094</p>
                </div>
              </div>
              <div className="flex items-start gap-2">
                <Clock className="w-4 h-4 text-emerald-500 shrink-0 mt-0.5" />
                <span>Mon - Sat: 7:00 AM - 7:00 PM</span>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Copyright */}
        <div className="pt-8 border-t border-slate-900 flex flex-col sm:flex-row items-center justify-between text-xs text-slate-500 gap-4">
          <p>© {new Date().getFullYear()} THE YOUNG SHALL GROW — Tarkwa (Pepesa), Ghana. All Rights Reserved.</p>
          <p className="flex items-center gap-1">
            <span>Designed for Ghanaian Retail Excellence</span>
            <Heart className="w-3.5 h-3.5 text-red-500 fill-current" />
          </p>
        </div>
      </div>
    </footer>
  );
};
