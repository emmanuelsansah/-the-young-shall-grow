import React, { useState } from 'react';
import { useShop } from '../context/ShopContext';
import { X, Trash2, Plus, Minus, MessageSquare, ShoppingBag, Truck, MapPin, CheckCircle2, ArrowRight } from 'lucide-react';
import { CustomerDetails } from '../types/ecommerce';

export const CartDrawer: React.FC = () => {
  const {
    cart,
    cartDrawerOpen,
    setCartDrawerOpen,
    updateCartQuantity,
    removeFromCart,
    clearCart,
    placeOrder,
    generateWhatsAppLink,
    setCurrentPage
  } = useShop();

  const [step, setStep] = useState<'cart' | 'checkout' | 'success'>('cart');
  const [lastPlacedOrderId, setLastPlacedOrderId] = useState<string>('');

  const [customer, setCustomer] = useState<CustomerDetails>({
    fullName: '',
    phone: '',
    whatsappPhone: '',
    deliveryAddress: '',
    region: 'Western Region (Tarkwa)',
    city: 'Tarkwa Pepesa',
    deliveryMethod: 'Tarkwa Pick-Up',
    paymentMethod: 'Cash on Delivery / Pickup',
    orderNotes: ''
  });

  if (!cartDrawerOpen) return null;

  const subtotal = cart.reduce((sum, item) => sum + item.product.price * item.quantity, 0);
  const deliveryFee =
    customer.deliveryMethod === 'Tarkwa Pick-Up'
      ? 0
      : customer.deliveryMethod === 'Tarkwa Home Delivery'
      ? 20
      : 45;

  const total = subtotal + deliveryFee;

  const handleCheckoutSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customer.fullName || !customer.phone) {
      alert('Please fill in your name and phone number');
      return;
    }

    const order = placeOrder(customer);
    setLastPlacedOrderId(order.id);
    setStep('success');
  };

  const ghanaRegions = [
    'Western Region (Tarkwa)',
    'Greater Accra Region',
    'Ashanti Region (Kumasi)',
    'Western North Region',
    'Central Region (Cape Coast)',
    'Eastern Region (Koforidua)',
    'Volta Region (Ho)',
    'Northern Region (Tamale)',
    'Bono Region (Sunyani)',
    'Upper East / West'
  ];

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="absolute inset-y-0 right-0 max-w-full flex pl-10">
        <div className="w-screen max-w-md bg-white dark:bg-slate-900 shadow-2xl flex flex-col justify-between border-l border-slate-200 dark:border-slate-800">
          
          {/* Header */}
          <div className="p-4 bg-gradient-to-r from-red-700 via-orange-600 to-amber-600 text-white flex items-center justify-between">
            <div className="flex items-center gap-2 font-bold text-base">
              <ShoppingBag className="w-5 h-5 text-amber-200" />
              <span>{step === 'cart' ? 'Your Shopping Cart' : step === 'checkout' ? 'Customer & Delivery Info' : 'Order Placed!'}</span>
            </div>
            <button
              onClick={() => {
                setCartDrawerOpen(false);
                setStep('cart');
              }}
              className="p-1 rounded-lg hover:bg-white/20 text-white transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Body Content */}
          <div className="flex-1 overflow-y-auto p-4 space-y-4">
            {step === 'cart' && (
              <>
                {cart.length === 0 ? (
                  <div className="h-full flex flex-col items-center justify-center text-center p-6 text-slate-500">
                    <ShoppingBag className="w-16 h-16 text-slate-300 dark:text-slate-700 mb-4 stroke-1" />
                    <p className="font-bold text-base text-slate-700 dark:text-slate-300">Your cart is empty</p>
                    <p className="text-xs text-slate-400 mt-1 max-w-xs">
                      Explore our Ankara fabrics, Kente, Ecolac luggage, and gas cylinders!
                    </p>
                    <button
                      onClick={() => {
                        setCartDrawerOpen(false);
                        setCurrentPage('shop');
                      }}
                      className="mt-6 px-6 py-2.5 bg-red-600 hover:bg-red-700 text-white font-bold text-xs rounded-xl shadow transition-all"
                    >
                      Browse Shop Catalog
                    </button>
                  </div>
                ) : (
                  <div className="space-y-3">
                    <div className="flex items-center justify-between text-xs text-slate-500 pb-2 border-b border-slate-100 dark:border-slate-800">
                      <span>{cart.length} item(s) selected</span>
                      <button
                        onClick={clearCart}
                        className="text-red-500 hover:underline flex items-center gap-1 font-semibold"
                      >
                        <Trash2 className="w-3.5 h-3.5" /> Clear All
                      </button>
                    </div>

                    {cart.map((item, idx) => (
                      <div
                        key={idx}
                        className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-200/60 dark:border-slate-700/60 flex items-center gap-3"
                      >
                        <img
                          src={item.product.image}
                          alt={item.product.name}
                          referrerPolicy="no-referrer"
                          className="w-16 h-16 rounded-lg object-cover shrink-0 bg-white"
                        />
                        <div className="flex-1 min-w-0">
                          <h4 className="text-xs font-bold text-slate-900 dark:text-white truncate">
                            {item.product.name}
                          </h4>
                          {item.selectedColor && (
                            <span className="text-[10px] text-amber-600 font-semibold block">
                              Color/Pattern: {item.selectedColor}
                            </span>
                          )}
                          <div className="mt-1 flex items-center justify-between">
                            <span className="text-sm font-black text-slate-900 dark:text-white tabular-nums">
                              GH₵ {(item.product.price * item.quantity).toLocaleString()}
                            </span>

                            {/* Stepper */}
                            <div className="flex items-center border border-slate-300 dark:border-slate-600 rounded bg-white dark:bg-slate-700">
                              <button
                                onClick={() => updateCartQuantity(item.product.id, item.quantity - 1)}
                                className="px-1.5 py-0.5 text-slate-600 dark:text-slate-300 hover:bg-slate-100"
                              >
                                <Minus className="w-3 h-3" />
                              </button>
                              <span className="px-2 py-0.5 text-xs font-bold tabular-nums">
                                {item.quantity}
                              </span>
                              <button
                                onClick={() => updateCartQuantity(item.product.id, item.quantity + 1)}
                                className="px-1.5 py-0.5 text-slate-600 dark:text-slate-300 hover:bg-slate-100"
                              >
                                <Plus className="w-3 h-3" />
                              </button>
                            </div>
                          </div>
                        </div>
                        <button
                          onClick={() => removeFromCart(item.product.id)}
                          className="text-slate-400 hover:text-red-500 p-1"
                        >
                          <X className="w-4 h-4" />
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </>
            )}

            {step === 'checkout' && (
              <form id="checkout-form" onSubmit={handleCheckoutSubmit} className="space-y-4 text-xs">
                <div>
                  <label className="block font-bold text-slate-700 dark:text-slate-200 mb-1">
                    Full Name *
                  </label>
                  <input
                    type="text"
                    required
                    value={customer.fullName}
                    onChange={(e) => setCustomer({ ...customer, fullName: e.target.value })}
                    placeholder="e.g. Kwame Mensah"
                    className="w-full px-3 py-2 bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white focus:ring-2 focus:ring-red-500 focus:outline-none"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block font-bold text-slate-700 dark:text-slate-200 mb-1">
                      Phone Number *
                    </label>
                    <input
                      type="tel"
                      required
                      value={customer.phone}
                      onChange={(e) => setCustomer({ ...customer, phone: e.target.value })}
                      placeholder="024XXXXXXX"
                      className="w-full px-3 py-2 bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white focus:ring-2 focus:ring-red-500 focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="block font-bold text-slate-700 dark:text-slate-200 mb-1">
                      Town / City
                    </label>
                    <input
                      type="text"
                      value={customer.city}
                      onChange={(e) => setCustomer({ ...customer, city: e.target.value })}
                      placeholder="Tarkwa Pepesa"
                      className="w-full px-3 py-2 bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white focus:ring-2 focus:ring-red-500 focus:outline-none"
                    />
                  </div>
                </div>

                <div>
                  <label className="block font-bold text-slate-700 dark:text-slate-200 mb-1">
                    Region in Ghana
                  </label>
                  <select
                    value={customer.region}
                    onChange={(e) => setCustomer({ ...customer, region: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white focus:ring-2 focus:ring-red-500 focus:outline-none"
                  >
                    {ghanaRegions.map((reg) => (
                      <option key={reg} value={reg}>
                        {reg}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block font-bold text-slate-700 dark:text-slate-200 mb-1">
                    Delivery / Landmark Address
                  </label>
                  <textarea
                    rows={2}
                    value={customer.deliveryAddress}
                    onChange={(e) => setCustomer({ ...customer, deliveryAddress: e.target.value })}
                    placeholder="e.g. Pepesa Junction, Near UMaT Main Gate, Tarkwa"
                    className="w-full px-3 py-2 bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white focus:ring-2 focus:ring-red-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 dark:text-slate-200 mb-1">
                    Delivery Option
                  </label>
                  <div className="space-y-2">
                    {[
                      { id: 'Tarkwa Pick-Up', label: 'Tarkwa Pepesa Store Pick-Up', fee: 'Free (GH₵ 0)' },
                      { id: 'Tarkwa Home Delivery', label: 'Tarkwa Local Doorstep Delivery', fee: 'GH₵ 20' },
                      { id: 'Nationwide Ghana Shipping (STC/VIP Bus)', label: 'Nationwide Ghana Parcel Shipping', fee: 'GH₵ 45' }
                    ].map((opt) => (
                      <label
                        key={opt.id}
                        className={`flex items-center justify-between p-2.5 rounded-lg border cursor-pointer transition-colors ${
                          customer.deliveryMethod === opt.id
                            ? 'border-red-600 bg-red-50 dark:bg-slate-800 font-bold'
                            : 'border-slate-200 dark:border-slate-700'
                        }`}
                      >
                        <div className="flex items-center gap-2">
                          <input
                            type="radio"
                            name="delivery"
                            checked={customer.deliveryMethod === opt.id}
                            onChange={() => setCustomer({ ...customer, deliveryMethod: opt.id as any })}
                            className="text-red-600 focus:ring-red-500"
                          />
                          <span className="text-slate-900 dark:text-white">{opt.label}</span>
                        </div>
                        <span className="text-slate-500 font-mono text-[11px]">{opt.fee}</span>
                      </label>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="block font-bold text-slate-700 dark:text-slate-200 mb-1">
                    Payment Preference
                  </label>
                  <select
                    value={customer.paymentMethod}
                    onChange={(e) => setCustomer({ ...customer, paymentMethod: e.target.value as any })}
                    className="w-full px-3 py-2 bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white focus:ring-2 focus:ring-red-500 focus:outline-none"
                  >
                    <option value="Cash on Delivery / Pickup">Cash on Delivery / Pickup at Tarkwa</option>
                    <option value="Mobile Money (MTN / Telecel / AT)">Mobile Money (MoMo - MTN / Telecel)</option>
                    <option value="Bank Transfer">Bank Transfer</option>
                  </select>
                </div>
              </form>
            )}

            {step === 'success' && (
              <div className="text-center py-8 space-y-4">
                <div className="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto shadow-inner">
                  <CheckCircle2 className="w-10 h-10" />
                </div>
                <h3 className="text-xl font-black text-slate-900 dark:text-white">
                  Order Successfully Created!
                </h3>
                <p className="text-xs text-slate-600 dark:text-slate-400">
                  Your Order Reference ID is <span className="font-bold text-red-600">{lastPlacedOrderId}</span>.
                </p>

                <div className="p-4 bg-amber-50 dark:bg-slate-800 rounded-xl border border-amber-200 dark:border-slate-700 text-left text-xs space-y-2">
                  <p className="font-bold text-amber-900 dark:text-amber-300">⚡ Send directly to WhatsApp now:</p>
                  <p className="text-slate-600 dark:text-slate-300">
                    Click below to launch WhatsApp with your item list pre-filled to our Tarkwa store team (0241890996).
                  </p>
                  <a
                    href={generateWhatsAppLink('0241890996', cart, subtotal, customer)}
                    target="_blank"
                    rel="noreferrer"
                    className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl flex items-center justify-center gap-2 text-xs shadow-md transition-all"
                  >
                    <MessageSquare className="w-4 h-4" /> Send Order to WhatsApp (0241890996)
                  </a>
                  <a
                    href={generateWhatsAppLink('0243276094', cart, subtotal, customer)}
                    target="_blank"
                    rel="noreferrer"
                    className="w-full py-2 bg-slate-800 hover:bg-slate-900 text-white font-bold rounded-xl flex items-center justify-center gap-2 text-xs transition-all"
                  >
                    <MessageSquare className="w-3.5 h-3.5" /> Alternative Line (0243276094)
                  </a>
                </div>
              </div>
            )}
          </div>

          {/* Footer Summary & Primary CTAs */}
          {cart.length > 0 && step !== 'success' && (
            <div className="p-4 bg-slate-50 dark:bg-slate-800/80 border-t border-slate-200 dark:border-slate-700 space-y-3">
              <div className="space-y-1 text-xs">
                <div className="flex justify-between text-slate-600 dark:text-slate-400">
                  <span>Subtotal:</span>
                  <span className="font-bold tabular-nums">GH₵ {subtotal.toLocaleString()}</span>
                </div>
                {step === 'checkout' && (
                  <div className="flex justify-between text-slate-600 dark:text-slate-400">
                    <span>Delivery Fee ({customer.deliveryMethod}):</span>
                    <span className="font-bold tabular-nums">GH₵ {deliveryFee}</span>
                  </div>
                )}
                <div className="flex justify-between text-base font-black text-slate-900 dark:text-white pt-1 border-t border-slate-200 dark:border-slate-700">
                  <span>Total Amount:</span>
                  <span className="text-red-600 tabular-nums">
                    GH₵ {(step === 'checkout' ? total : subtotal).toLocaleString()}
                  </span>
                </div>
              </div>

              {step === 'cart' ? (
                <div className="space-y-2">
                  <button
                    onClick={() => setStep('checkout')}
                    className="w-full py-3 bg-gradient-to-r from-red-600 to-amber-600 hover:from-red-700 hover:to-amber-700 text-white font-bold text-xs rounded-xl shadow-lg flex items-center justify-center gap-2 transition-all"
                  >
                    Proceed to Customer Checkout <ArrowRight className="w-4 h-4" />
                  </button>

                  <a
                    href={generateWhatsAppLink('0241890996', cart, subtotal)}
                    target="_blank"
                    rel="noreferrer"
                    className="w-full py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow flex items-center justify-center gap-2 transition-all"
                  >
                    <MessageSquare className="w-4 h-4" /> Instant 1-Click WhatsApp Order
                  </a>
                </div>
              ) : (
                <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={() => setStep('cart')}
                    className="w-1/3 py-3 bg-slate-200 dark:bg-slate-700 text-slate-800 dark:text-slate-200 font-bold text-xs rounded-xl"
                  >
                    Back
                  </button>
                  <button
                    type="submit"
                    form="checkout-form"
                    className="w-2/3 py-3 bg-red-600 hover:bg-red-700 text-white font-bold text-xs rounded-xl shadow-lg flex items-center justify-center gap-1"
                  >
                    Confirm & Place Order
                  </button>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
