import React from 'react';
import { Product } from '../types/ecommerce';
import { useShop } from '../context/ShopContext';
import { ShoppingBag, Eye, Heart, MessageSquare, Check, AlertCircle } from 'lucide-react';

interface ProductCardProps {
  product: Product;
}

export const ProductCard: React.FC<ProductCardProps> = ({ product }) => {
  const { addToCart, openProductDetail, wishlist, toggleWishlist, generateProductWhatsAppLink } = useShop();
  const isWishlisted = wishlist.includes(product.id);

  return (
    <div className="group bg-white dark:bg-slate-800 rounded-2xl border border-slate-200/80 dark:border-slate-700/80 overflow-hidden shadow-sm hover:shadow-xl transition-all duration-300 flex flex-col justify-between">
      {/* Product Image Area */}
      <div className="relative aspect-[4/3] bg-slate-100 dark:bg-slate-900 overflow-hidden">
        <img
          src={product.image}
          alt={product.name}
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
          onError={(e) => {
            // CSS SVG Fallback on image error
            (e.target as HTMLElement).style.display = 'none';
            const parent = (e.target as HTMLElement).parentElement;
            if (parent && !parent.querySelector('.fallback-box')) {
              const div = document.createElement('div');
              div.className = 'fallback-box w-full h-full flex flex-col items-center justify-center bg-slate-200 text-slate-500 p-4 text-center';
              div.innerHTML = `<span class="text-xs font-bold">${product.category}</span><span class="text-sm font-semibold">${product.name}</span>`;
              parent.appendChild(div);
            }
          }}
        />

        {/* Top Badges */}
        <div className="absolute top-3 left-3 flex flex-col gap-1 items-start z-10">
          {product.bestSeller && (
            <span className="bg-amber-500 text-white text-[10px] font-extrabold uppercase px-2 py-0.5 rounded shadow">
              Best Seller
            </span>
          )}
          {product.newArrival && (
            <span className="bg-red-600 text-white text-[10px] font-extrabold uppercase px-2 py-0.5 rounded shadow">
              New Arrival
            </span>
          )}
        </div>

        {/* Wishlist Button */}
        <button
          onClick={(e) => {
            e.stopPropagation();
            toggleWishlist(product.id);
          }}
          className={`absolute top-3 right-3 p-2 rounded-full backdrop-blur-md shadow-md transition-all ${
            isWishlisted
              ? 'bg-red-600 text-white'
              : 'bg-white/80 dark:bg-slate-800/80 text-slate-700 dark:text-slate-200 hover:bg-white dark:hover:bg-slate-800'
          }`}
          title="Save to favorites"
        >
          <Heart className={`w-4 h-4 ${isWishlisted ? 'fill-current' : ''}`} />
        </button>

        {/* Quick View Hover Overlay */}
        <div className="absolute inset-0 bg-slate-900/30 backdrop-blur-[2px] opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-3">
          <button
            onClick={() => openProductDetail(product)}
            className="bg-white text-slate-900 font-bold text-xs px-3 py-2 rounded-lg shadow-lg flex items-center gap-1.5 hover:bg-red-50 hover:text-red-600 transition-colors"
          >
            <Eye className="w-4 h-4" /> Quick View
          </button>
        </div>
      </div>

      {/* Card Body */}
      <div className="p-4 flex-1 flex flex-col justify-between">
        <div>
          {/* Unboxed Metadata (Zero-Pill Discipline) */}
          <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400 mb-1">
            <span className="font-semibold text-slate-600 dark:text-slate-300">{product.category}</span>
            <span aria-hidden="true">•</span>
            <span>{product.unit || 'Standard'}</span>
          </div>

          <h3
            onClick={() => openProductDetail(product)}
            className="font-bold text-slate-900 dark:text-white text-base leading-snug line-clamp-2 hover:text-red-600 dark:hover:text-red-400 cursor-pointer transition-colors"
          >
            {product.name}
          </h3>

          <p className="text-xs text-slate-600 dark:text-slate-400 mt-1 line-clamp-2">
            {product.description}
          </p>
        </div>

        {/* Pricing & Stock Bar */}
        <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-700/60 flex items-center justify-between">
          <div>
            <div className="flex items-baseline gap-2">
              <span className="text-lg font-black text-slate-900 dark:text-white tabular-nums">
                GH₵ {product.price.toLocaleString()}
              </span>
              {product.originalPrice && (
                <span className="text-xs text-slate-400 line-through tabular-nums">
                  GH₵ {product.originalPrice.toLocaleString()}
                </span>
              )}
            </div>
            <div className="flex items-center gap-1 text-[11px] mt-0.5">
              {product.inStock ? (
                <span className="text-emerald-600 dark:text-emerald-400 font-semibold flex items-center gap-1">
                  <Check className="w-3 h-3" /> In Stock ({product.stockQuantity})
                </span>
              ) : (
                <span className="text-red-500 font-semibold flex items-center gap-1">
                  <AlertCircle className="w-3 h-3" /> Out of Stock
                </span>
              )}
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center gap-1.5">
            <a
              href={generateProductWhatsAppLink(product)}
              target="_blank"
              rel="noreferrer"
              className="p-2 bg-emerald-50 dark:bg-emerald-950/40 text-emerald-600 dark:text-emerald-400 rounded-lg hover:bg-emerald-600 hover:text-white transition-colors"
              title="Order directly on WhatsApp"
            >
              <MessageSquare className="w-4 h-4" />
            </a>

            <button
              onClick={() => addToCart(product, 1)}
              disabled={!product.inStock}
              className="px-3 py-2 bg-gradient-to-r from-red-600 to-amber-600 hover:from-red-700 hover:to-amber-700 disabled:opacity-50 text-white text-xs font-bold rounded-lg shadow-sm flex items-center gap-1.5 transition-all active:scale-95"
            >
              <ShoppingBag className="w-3.5 h-3.5" /> Add
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
