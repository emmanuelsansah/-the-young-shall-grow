import React, { useState } from 'react';
import { useShop } from '../context/ShopContext';
import { X, ShoppingBag, MessageSquare, Check, ShieldCheck, Truck, RotateCcw, Minus, Plus, Heart } from 'lucide-react';

export const ProductModal: React.FC = () => {
  const { selectedProduct, closeProductDetail, addToCart, generateProductWhatsAppLink, wishlist, toggleWishlist } = useShop();
  const [quantity, setQuantity] = useState(1);
  const [selectedColor, setSelectedColor] = useState<string>(
    selectedProduct?.colors?.[0] || ''
  );

  if (!selectedProduct) return null;

  const isWishlisted = wishlist.includes(selectedProduct.id);

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/70 backdrop-blur-sm flex items-center justify-center p-4 sm:p-6 animate-in fade-in duration-200">
      <div className="relative bg-white dark:bg-slate-900 w-full max-w-4xl rounded-3xl shadow-2xl overflow-hidden border border-slate-200 dark:border-slate-800 my-8">
        
        {/* Close Button */}
        <button
          onClick={closeProductDetail}
          className="absolute top-4 right-4 z-20 p-2 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-red-50 hover:text-red-600 transition-colors"
        >
          <X className="w-6 h-6" />
        </button>

        <div className="grid grid-cols-1 md:grid-cols-2">
          {/* Left Column: Image */}
          <div className="bg-slate-100 dark:bg-slate-950 p-6 flex flex-col items-center justify-center relative">
            <div className="w-full aspect-square rounded-2xl overflow-hidden shadow-md bg-white">
              <img
                src={selectedProduct.image}
                alt={selectedProduct.name}
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover"
              />
            </div>
            
            {/* Color/Pattern thumbnails if available */}
            {selectedProduct.colors && selectedProduct.colors.length > 0 && (
              <div className="mt-4 w-full">
                <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider block mb-2">
                  Available Variations / Colors:
                </span>
                <div className="flex flex-wrap gap-2">
                  {selectedProduct.colors.map((col) => (
                    <button
                      key={col}
                      onClick={() => setSelectedColor(col)}
                      className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                        selectedColor === col
                          ? 'bg-red-600 text-white shadow-md'
                          : 'bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:border-red-500'
                      }`}
                    >
                      {col}
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Right Column: Contiguous Purchase Module */}
          <div className="p-6 sm:p-8 flex flex-col justify-between space-y-6">
            <div>
              {/* Category & Rating */}
              <div className="flex items-center justify-between text-xs text-slate-500 mb-2">
                <span className="font-bold text-red-600 uppercase tracking-wider">
                  {selectedProduct.category}
                </span>
                <span className="flex items-center gap-1 font-medium text-amber-500">
                  ★ {selectedProduct.rating} ({selectedProduct.reviewCount} customer reviews)
                </span>
              </div>

              <h2 className="text-2xl font-extrabold text-slate-900 dark:text-white leading-tight">
                {selectedProduct.name}
              </h2>

              {/* Price Banner */}
              <div className="mt-4 flex items-baseline gap-3">
                <span className="text-3xl font-black text-slate-900 dark:text-white tabular-nums">
                  GH₵ {selectedProduct.price.toLocaleString()}
                </span>
                {selectedProduct.originalPrice && (
                  <span className="text-base text-slate-400 line-through tabular-nums">
                    GH₵ {selectedProduct.originalPrice.toLocaleString()}
                  </span>
                )}
                <span className="text-xs bg-emerald-100 text-emerald-800 font-bold px-2 py-0.5 rounded">
                  {selectedProduct.unit || 'Standard Unit'}
                </span>
              </div>

              {/* Description */}
              <p className="mt-4 text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
                {selectedProduct.description}
              </p>

              {/* Specs / Features List */}
              {selectedProduct.features && selectedProduct.features.length > 0 && (
                <div className="mt-4 bg-slate-50 dark:bg-slate-800/50 p-3 rounded-xl space-y-1.5 border border-slate-200/60 dark:border-slate-700/60">
                  {selectedProduct.features.map((feat, idx) => (
                    <div key={idx} className="flex items-center gap-2 text-xs text-slate-700 dark:text-slate-300">
                      <Check className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                      <span>{feat}</span>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Quantity Selector & Buy CTAs */}
            <div className="space-y-4 pt-4 border-t border-slate-100 dark:border-slate-800">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-700 dark:text-slate-300">Quantity:</span>
                <div className="flex items-center border border-slate-300 dark:border-slate-700 rounded-lg overflow-hidden">
                  <button
                    onClick={() => setQuantity(Math.max(1, quantity - 1))}
                    className="px-3 py-1 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 hover:bg-slate-200"
                  >
                    <Minus className="w-3.5 h-3.5" />
                  </button>
                  <span className="px-4 py-1 text-sm font-bold text-slate-900 dark:text-white tabular-nums">
                    {quantity}
                  </span>
                  <button
                    onClick={() => setQuantity(quantity + 1)}
                    className="px-3 py-1 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 hover:bg-slate-200"
                  >
                    <Plus className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <button
                  onClick={() => {
                    addToCart(selectedProduct, quantity, selectedColor);
                    closeProductDetail();
                  }}
                  className="w-full py-3 bg-gradient-to-r from-red-600 to-amber-600 hover:from-red-700 hover:to-amber-700 text-white font-bold rounded-xl shadow-lg flex items-center justify-center gap-2 text-sm transition-all"
                >
                  <ShoppingBag className="w-4 h-4" /> Add to Cart (GH₵ {(selectedProduct.price * quantity).toLocaleString()})
                </button>

                <a
                  href={generateProductWhatsAppLink(selectedProduct)}
                  target="_blank"
                  rel="noreferrer"
                  className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl shadow-lg flex items-center justify-center gap-2 text-sm transition-all"
                >
                  <MessageSquare className="w-4 h-4" /> Order via WhatsApp
                </a>
              </div>

              {/* Trust Badges */}
              <div className="grid grid-cols-3 gap-2 pt-2 text-[11px] text-slate-500 text-center">
                <div className="flex flex-col items-center gap-1">
                  <Truck className="w-4 h-4 text-red-600" />
                  <span>Nationwide Ghana Delivery</span>
                </div>
                <div className="flex flex-col items-center gap-1">
                  <ShieldCheck className="w-4 h-4 text-emerald-600" />
                  <span>Verified Quality Guarantee</span>
                </div>
                <div className="flex flex-col items-center gap-1">
                  <RotateCcw className="w-4 h-4 text-amber-600" />
                  <span>Tarkwa Store Pickup</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
