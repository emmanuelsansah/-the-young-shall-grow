import React, { useState } from 'react';
import { ShoppingBag, Search, Shield, Phone, MessageSquare, Menu, X, ChevronDown, MapPin } from 'lucide-react';
import { useShop } from '../context/ShopContext';
import { ProductCategory } from '../types/ecommerce';

export const Navbar: React.FC = () => {
  const {
    currentPage,
    setCurrentPage,
    cart,
    selectedCategory,
    setSelectedCategory,
    searchQuery,
    setSearchQuery,
    setCartDrawerOpen,
    isAdmin,
    setIsAdmin
  } = useShop();

  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [categoriesOpen, setCategoriesOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);

  const cartItemCount = cart.reduce((total, item) => total + item.quantity, 0);

  const categories: ProductCategory[] = [
    'Ankara Fabrics',
    'Kente Fabrics',
    'Lining Materials',
    'Sewing Materials',
    "Men's Fabrics",
    "Women's Fabrics",
    'Corporate & Occasional Outfit Materials',
    'Ecolac Bags',
    'Gas Cylinders',
    'Other Available Products'
  ];

  const handleNav = (page: typeof currentPage) => {
    setCurrentPage(page);
    setMobileMenuOpen(false);
    setCategoriesOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleCategoryClick = (cat: ProductCategory) => {
    setSelectedCategory(cat);
    setCurrentPage('shop');
    setCategoriesOpen(false);
    setMobileMenuOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <header className="sticky top-0 z-40 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-b border-slate-200 dark:border-slate-800 transition-colors">
      {/* Top Announcement Bar */}
      <div className="bg-gradient-to-r from-red-700 via-orange-600 to-amber-600 text-white text-xs py-1.5 px-4 font-medium">
        <div className="max-w-7xl mx-mx px-2 sm:px-6 lg:px-8 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <MapPin className="w-3.5 h-3.5 text-amber-200" />
            <span className="truncate">Tarkwa (Pepesa), Ghana — Nationwide Delivery Available</span>
          </div>
          <div className="hidden md:flex items-center gap-4 text-amber-100">
            <a href="tel:0241890996" className="hover:underline flex items-center gap-1">
              <Phone className="w-3 h-3" /> 0241890996
            </a>
            <span>•</span>
            <a href="tel:0243276094" className="hover:underline flex items-center gap-1">
              <Phone className="w-3 h-3" /> 0243276094
            </a>
            <span>•</span>
            <a
              href="https://wa.me/233241890996"
              target="_blank"
              rel="noreferrer"
              className="bg-emerald-600 hover:bg-emerald-700 text-white px-2 py-0.5 rounded text-[11px] font-semibold flex items-center gap-1 transition-colors"
            >
              <MessageSquare className="w-3 h-3" /> WhatsApp Order
            </a>
          </div>
        </div>
      </div>

      {/* Main Top Bar Navigation */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-18 flex items-center justify-between gap-6">
        
        {/* Zone 1: Brand Wordmark */}
        <div className="flex items-center gap-3 shrink-0">
          <button
            onClick={() => handleNav('home')}
            className="text-left group flex items-center gap-2"
          >
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-red-600 to-amber-500 flex items-center justify-center text-white font-black text-xl shadow-md group-hover:scale-105 transition-transform">
              Y
            </div>
            <div>
              <span className="text-lg sm:text-xl font-extrabold tracking-tight text-slate-900 dark:text-white block leading-none">
                THE YOUNG SHALL GROW
              </span>
              <span className="text-[10px] font-semibold text-red-600 dark:text-red-400 tracking-wider uppercase">
                TARKWA (PEPESA) • GHANA
              </span>
            </div>
          </button>
        </div>

        {/* Zone 2: Navigation Links (Desktop) */}
        <nav className="hidden lg:flex items-center gap-7 text-sm font-semibold text-slate-700 dark:text-slate-200">
          <button
            onClick={() => handleNav('home')}
            className={`transition-colors hover:text-red-600 ${
              currentPage === 'home' ? 'text-red-600 dark:text-red-400 font-bold border-b-2 border-red-600 py-1' : ''
            }`}
          >
            Home
          </button>

          <button
            onClick={() => {
              setSelectedCategory('All');
              handleNav('shop');
            }}
            className={`transition-colors hover:text-red-600 ${
              currentPage === 'shop' && selectedCategory === 'All'
                ? 'text-red-600 dark:text-red-400 font-bold border-b-2 border-red-600 py-1'
                : ''
            }`}
          >
            Shop
          </button>

          {/* Categories Dropdown */}
          <div className="relative">
            <button
              onClick={() => setCategoriesOpen(!categoriesOpen)}
              className="flex items-center gap-1 hover:text-red-600 transition-colors py-1"
            >
              <span>Categories</span>
              <ChevronDown className={`w-4 h-4 transition-transform ${categoriesOpen ? 'rotate-180' : ''}`} />
            </button>

            {categoriesOpen && (
              <div className="absolute top-full left-0 mt-2 w-64 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl shadow-xl py-2 z-50 animate-in fade-in slide-in-from-top-2 duration-150">
                <button
                  onClick={() => handleCategoryClick('All' as any)}
                  className="w-full text-left px-4 py-2 text-xs font-semibold text-slate-900 dark:text-white hover:bg-red-50 dark:hover:bg-slate-700 hover:text-red-600"
                >
                  All Categories ({categories.length})
                </button>
                <div className="h-px bg-slate-100 dark:bg-slate-700 my-1" />
                {categories.map((cat) => (
                  <button
                    key={cat}
                    onClick={() => handleCategoryClick(cat)}
                    className={`w-full text-left px-4 py-2 text-xs transition-colors ${
                      selectedCategory === cat
                        ? 'font-bold text-red-600 bg-red-50 dark:bg-slate-700'
                        : 'text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-700/50 hover:text-red-600'
                    }`}
                  >
                    {cat}
                  </button>
                ))}
              </div>
            )}
          </div>

          <button
            onClick={() => handleNav('about')}
            className={`transition-colors hover:text-red-600 ${
              currentPage === 'about' ? 'text-red-600 dark:text-red-400 font-bold border-b-2 border-red-600 py-1' : ''
            }`}
          >
            About Us
          </button>

          <button
            onClick={() => handleNav('contact')}
            className={`transition-colors hover:text-red-600 ${
              currentPage === 'contact' ? 'text-red-600 dark:text-red-400 font-bold border-b-2 border-red-600 py-1' : ''
            }`}
          >
            Contact
          </button>
        </nav>

        {/* Zone 3: Actions */}
        <div className="flex items-center gap-3 shrink-0">
          {/* Search Trigger / Input */}
          <div className="relative">
            {searchOpen ? (
              <div className="flex items-center gap-1 bg-slate-100 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg px-2 py-1.5 animate-in fade-in duration-150">
                <Search className="w-4 h-4 text-slate-400" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') {
                      setCurrentPage('shop');
                    }
                  }}
                  placeholder="Search Ankara, Kente, Bags..."
                  className="w-36 sm:w-48 text-xs bg-transparent focus:outline-none text-slate-900 dark:text-white"
                  autoFocus
                />
                <button
                  onClick={() => {
                    setSearchOpen(false);
                    setSearchQuery('');
                  }}
                  className="text-slate-400 hover:text-slate-600"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>
            ) : (
              <button
                onClick={() => {
                  setSearchOpen(true);
                  if (currentPage !== 'shop') setCurrentPage('shop');
                }}
                className="p-2 rounded-lg text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                title="Search products"
              >
                <Search className="w-5 h-5" />
              </button>
            )}
          </div>

          {/* Cart Icon Button */}
          <button
            onClick={() => setCartDrawerOpen(true)}
            className="relative p-2 rounded-lg text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            title="View Shopping Cart"
          >
            <ShoppingBag className="w-5 h-5 text-red-600" />
            {cartItemCount > 0 && (
              <span className="absolute -top-1 -right-1 bg-red-600 text-white text-[10px] font-bold rounded-full w-5 h-5 flex items-center justify-center shadow-md animate-pulse">
                {cartItemCount}
              </span>
            )}
          </button>

          {/* Admin Dashboard Portal Icon */}
          <button
            onClick={() => handleNav('admin')}
            className={`p-2 rounded-lg transition-colors flex items-center gap-1 text-xs font-semibold ${
              isAdmin || currentPage === 'admin'
                ? 'bg-amber-100 text-amber-900 border border-amber-300'
                : 'text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
            }`}
            title="Admin Portal"
          >
            <Shield className="w-4 h-4 text-amber-600" />
            <span className="hidden xl:inline">Admin</span>
          </button>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="lg:hidden p-2 rounded-lg text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 px-4 pt-3 pb-6 space-y-3 animate-in slide-in-from-top-4 duration-200">
          <button
            onClick={() => handleNav('home')}
            className={`w-full text-left py-2 font-semibold text-sm ${currentPage === 'home' ? 'text-red-600' : 'text-slate-800 dark:text-slate-200'}`}
          >
            Home
          </button>
          <button
            onClick={() => {
              setSelectedCategory('All');
              handleNav('shop');
            }}
            className={`w-full text-left py-2 font-semibold text-sm ${currentPage === 'shop' ? 'text-red-600' : 'text-slate-800 dark:text-slate-200'}`}
          >
            Shop All Products
          </button>

          {/* Mobile Categories list */}
          <div className="pl-3 border-l-2 border-red-500 space-y-1 my-2">
            <p className="text-[11px] font-extrabold uppercase tracking-wider text-slate-400 mb-1">Product Categories</p>
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => handleCategoryClick(cat)}
                className="w-full text-left py-1 text-xs text-slate-600 dark:text-slate-300 hover:text-red-600"
              >
                • {cat}
              </button>
            ))}
          </div>

          <button
            onClick={() => handleNav('about')}
            className={`w-full text-left py-2 font-semibold text-sm ${currentPage === 'about' ? 'text-red-600' : 'text-slate-800 dark:text-slate-200'}`}
          >
            About Us
          </button>
          <button
            onClick={() => handleNav('contact')}
            className={`w-full text-left py-2 font-semibold text-sm ${currentPage === 'contact' ? 'text-red-600' : 'text-slate-800 dark:text-slate-200'}`}
          >
            Contact
          </button>

          <div className="pt-2 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
            <a
              href="https://wa.me/233241890996"
              target="_blank"
              rel="noreferrer"
              className="w-full text-center bg-emerald-600 text-white font-semibold py-2 rounded-lg text-xs flex items-center justify-center gap-2"
            >
              <MessageSquare className="w-4 h-4" /> Order on WhatsApp (0241890996)
            </a>
          </div>
        </div>
      )}
    </header>
  );
};
