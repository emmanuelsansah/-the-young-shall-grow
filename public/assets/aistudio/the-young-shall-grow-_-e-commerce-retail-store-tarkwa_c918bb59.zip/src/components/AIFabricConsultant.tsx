import React, { useState } from 'react';
import { Sparkles, MessageSquare, X, Send, Bot, User, Calculator, Scissors } from 'lucide-react';
import { useShop } from '../context/ShopContext';
import { GoogleGenAI } from '@google/genai';

interface ChatMessage {
  sender: 'ai' | 'user';
  text: string;
  recommendations?: string[];
}

export const AIFabricConsultant: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      sender: 'ai',
      text: "Hello! I am your AI Fabric & Shopping Assistant for **THE YOUNG SHALL GROW (Tarkwa)**. Ask me how many yards of Ankara or Cashmere fabric you need for your outfit, gas cylinder safety recommendations, or Ecolac luggage advice!",
      recommendations: [
        "How many yards for a Ghanaian Men's Kaftan?",
        "How many yards for Kaba & Slit?",
        "What lining material is best for Ankara?",
        "Which Ecolac bag is best for travel?"
      ]
    }
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const { products, openProductDetail, setCurrentPage, setSelectedCategory } = useShop();

  const handleSend = async (userText: string) => {
    if (!userText.trim()) return;

    const newMessages: ChatMessage[] = [...messages, { sender: 'user', text: userText }];
    setMessages(newMessages);
    setInput('');
    setLoading(true);

    try {
      // Check if Gemini API key is available via import.meta.env or default
      const apiKey = import.meta.env.VITE_GEMINI_API_KEY || (window as any).GEMINI_API_KEY || '';
      
      let aiResponseText = '';

      if (apiKey) {
        const ai = new GoogleGenAI({ apiKey });
        const catalogContext = products.map(p => `• ${p.name} (GH₵ ${p.price}, Category: ${p.category})`).join('\n');
        
        const prompt = `You are the expert Ghanaian tailoring, fabric, and retail consultant for "THE YOUNG SHALL GROW" based in Tarkwa (Pepesa), Ghana.
Our store slogan: "Where Quality Meets Affordability. Your Comfort, Our Promise."
Our contact numbers: 0241890996 / 0243276094.

Available products in store:
${catalogContext}

User Query: "${userText}"

Provide a friendly, helpful, expert response tailored to Ghana tailors, fashion designers, and shoppers.
Include:
1. Exact fabric yardage calculations if asked about sewing outfits (e.g. 4 yards for male Senator/Kaftan, 6 yards for full Kaba & Slit, 3 yards for trousers/shirts).
2. Recommend specific items from our available catalog above when relevant.
3. Keep response warm, professional, concise, and encourage contacting us on WhatsApp (0241890996 / 0243276094) or visiting our Tarkwa Pepesa store.`;

        const response = await ai.models.generateContent({
          model: 'gemini-2.5-flash',
          contents: prompt
        });
        aiResponseText = response.text || 'Thank you for your question! Visit us at Tarkwa Pepesa or WhatsApp 0241890996 for assistance.';
      } else {
        // High quality fallback responses for common tailoring & retail queries
        const lower = userText.toLowerCase();
        if (lower.includes('kaftan') || lower.includes('senator') || lower.includes('men')) {
          aiResponseText = `For a classic Ghanaian **Men's Senator Kaftan Outfit**, you typically need **4 yards** of high-quality fabric (such as our Italian Wool Cashmere or GTP Ankara). If the person is very tall or plus-size, 4.5 to 5 yards is recommended. We also recommend pairing it with 2 yards of soft silk satin lining for smooth finish!`;
        } else if (lower.includes('kaba') || lower.includes('slit') || lower.includes('women')) {
          aiResponseText = `For a traditional Ghanaian **Kaba & Slit**, a standard **6-yard piece** of GTP Super Flash Ankara or Voile Lace is ideal! This provides enough fabric for the Kaba blouse, double slit skirt, and headwrap (Gele). We have authentic GTP Ankara (6 yards) for GH₵ 380!`;
        } else if (lower.includes('lining')) {
          aiResponseText = `For Ankara dresses and Senator suits, our **Silk Satin Lining** (GH₵ 25/yard) is the best choice! It prevents itching, retains warmth comfortably, and gives your outfit a crisp bespoke look.`;
        } else if (lower.includes('ecolac') || lower.includes('bag') || lower.includes('luggage')) {
          aiResponseText = `Our **Ecolac 3-Piece Luggage Set** (GH₵ 1,450) is crafted from unbreakable polycarbonate with 360° spinner wheels. The 20" is perfect for carry-on, 24" for 1-week travel, and 28" for long international journeys or university relocations.`;
        } else {
          aiResponseText = `At **THE YOUNG SHALL GROW (Tarkwa Pepesa)**, we guarantee top quality at affordable prices! You can order any of our products directly on WhatsApp at **0241890996** or **0243276094**. We deliver nationwide across Ghana!`;
        }
      }

      setMessages([...newMessages, { sender: 'ai', text: aiResponseText }]);
    } catch (err) {
      setMessages([
        ...newMessages,
        {
          sender: 'ai',
          text: "For custom fabric calculations or instant order assistance, please chat directly with our team on WhatsApp at **0241890996** or **0243276094**!"
        }
      ]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      {/* Floating Launcher Button */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="fixed bottom-6 right-6 z-40 bg-gradient-to-r from-red-600 to-amber-600 text-white p-4 rounded-full shadow-2xl hover:scale-105 active:scale-95 transition-all flex items-center gap-2 font-medium border-2 border-white/20"
        title="AI Tailoring & Fabric Assistant"
      >
        <Sparkles className="w-6 h-6 animate-pulse" />
        <span className="hidden sm:inline font-semibold text-sm">Fabric AI Assistant</span>
      </button>

      {/* AI Assistant Modal Window */}
      {isOpen && (
        <div className="fixed inset-0 sm:inset-auto sm:bottom-24 sm:right-6 sm:w-96 sm:h-[520px] z-50 bg-white dark:bg-slate-900 sm:rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 flex flex-col overflow-hidden animate-in fade-in slide-in-from-bottom-4 duration-200">
          {/* Header */}
          <div className="bg-gradient-to-r from-red-700 via-orange-600 to-amber-600 p-4 text-white flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-white/10 backdrop-blur-md rounded-lg">
                <Scissors className="w-5 h-5 text-amber-200" />
              </div>
              <div>
                <h3 className="font-bold text-sm tracking-wide">TYSG Fabric & Style AI</h3>
                <p className="text-xs text-amber-100/90">Tailoring Yardage & Retail Advisor</p>
              </div>
            </div>
            <button
              onClick={() => setIsOpen(false)}
              className="p-1 rounded-lg hover:bg-white/20 text-white transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Messages Body */}
          <div className="flex-1 p-4 overflow-y-auto space-y-4 bg-slate-50 dark:bg-slate-950/50">
            {messages.map((msg, index) => (
              <div
                key={index}
                className={`flex gap-3 ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                {msg.sender === 'ai' && (
                  <div className="w-8 h-8 rounded-full bg-red-600 text-white flex items-center justify-center shrink-0 shadow-sm mt-1">
                    <Bot className="w-4 h-4" />
                  </div>
                )}
                <div
                  className={`max-w-[82%] rounded-2xl p-3 text-xs leading-relaxed ${
                    msg.sender === 'user'
                      ? 'bg-red-600 text-white rounded-tr-none'
                      : 'bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-100 border border-slate-200 dark:border-slate-700 shadow-sm rounded-tl-none'
                  }`}
                >
                  <p className="whitespace-pre-line">{msg.text}</p>

                  {/* Preset prompt suggestions */}
                  {msg.recommendations && (
                    <div className="mt-3 pt-2 border-t border-slate-100 dark:border-slate-700 space-y-1.5">
                      <p className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider">Quick Suggestions:</p>
                      {msg.recommendations.map((rec, rIdx) => (
                        <button
                          key={rIdx}
                          onClick={() => handleSend(rec)}
                          className="w-full text-left p-1.5 rounded bg-slate-100 hover:bg-red-50 hover:text-red-700 dark:bg-slate-700 dark:hover:bg-slate-600 text-[11px] text-slate-700 dark:text-slate-200 transition-colors"
                        >
                          ⚡ {rec}
                        </button>
                      ))}
                    </div>
                  )}
                </div>
                {msg.sender === 'user' && (
                  <div className="w-8 h-8 rounded-full bg-slate-800 text-white flex items-center justify-center shrink-0 shadow-sm mt-1">
                    <User className="w-4 h-4" />
                  </div>
                )}
              </div>
            ))}
            {loading && (
              <div className="flex gap-3 items-center text-xs text-slate-500">
                <div className="w-8 h-8 rounded-full bg-red-600 text-white flex items-center justify-center shrink-0">
                  <Bot className="w-4 h-4 animate-spin" />
                </div>
                <span className="italic">Calculating yards and styling advice...</span>
              </div>
            )}
          </div>

          {/* Quick Actions Footer Bar */}
          <div className="p-2 bg-slate-100 dark:bg-slate-800 flex gap-2 border-t border-slate-200 dark:border-slate-700 overflow-x-auto">
            <button
              onClick={() => {
                setSelectedCategory('Ankara Fabrics');
                setCurrentPage('shop');
                setIsOpen(false);
              }}
              className="px-2.5 py-1 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded text-[11px] font-medium text-slate-700 dark:text-slate-200 whitespace-nowrap hover:border-red-500"
            >
              🧵 Shop Ankara
            </button>
            <button
              onClick={() => {
                setSelectedCategory('Kente Fabrics');
                setCurrentPage('shop');
                setIsOpen(false);
              }}
              className="px-2.5 py-1 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded text-[11px] font-medium text-slate-700 dark:text-slate-200 whitespace-nowrap hover:border-amber-500"
            >
              👑 Shop Kente
            </button>
            <button
              onClick={() => {
                setSelectedCategory('Ecolac Bags');
                setCurrentPage('shop');
                setIsOpen(false);
              }}
              className="px-2.5 py-1 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded text-[11px] font-medium text-slate-700 dark:text-slate-200 whitespace-nowrap hover:border-blue-500"
            >
              🧳 Ecolac Luggage
            </button>
          </div>

          {/* Input Box */}
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSend(input);
            }}
            className="p-3 bg-white dark:bg-slate-900 border-t border-slate-200 dark:border-slate-800 flex gap-2"
          >
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Ask about fabric yards, outfits, or gas..."
              className="flex-1 text-xs px-3 py-2 bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500 dark:text-white"
            />
            <button
              type="submit"
              disabled={loading || !input.trim()}
              className="px-3 py-2 bg-red-600 hover:bg-red-700 disabled:opacity-50 text-white rounded-lg text-xs font-semibold transition-colors flex items-center justify-center"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>
        </div>
      )}
    </>
  );
};
